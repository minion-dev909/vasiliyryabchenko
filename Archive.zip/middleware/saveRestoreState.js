export default function ({ route, store, from }) {
  if (from && route.path !== from.path + "/") {
    // Save the state if navigating to a child route
    store.commit("saveState");
  } else if (route.path === from.path + "/" && store.state.savedState) {
    // Restore the state if navigating back to a parent route
    store.commit("restoreState");
  }
}
