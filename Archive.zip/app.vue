<template>
  <NuxtLoadingIndicator color="black"/>
  <NuxtLayout name="default">
    <NuxtPage/>
  </NuxtLayout>
</template>