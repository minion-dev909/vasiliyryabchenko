// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
    runtimeConfig: {
    // The private keys which are only available within server-side
    // Keys within public, will be also exposed to the client-side
    public: {
      apiToken: process.env.API_TOKEN || "9eb455289debc779af1e04be1cbdbf306c9c00b38daa17f4aa384bf74118a9c68d91888998e1fbfc3b5645ca54367aee9ac7ec084fb80aae83bd7db284c42a64a20a1e55bdb1d1142eadf20c317fa4bd918e564d011a128247912d087930f28bb7504585357fe4ccce400fd2e82f369a1cfd021abfbc744945006ce784e4af3d",
      hubBase: process.env.API_BASE || "http://localhost:1337",
      apiBase: process.env.API_BASE || "http://localhost:1337/api",
      otherUrl: process.env.OTHER_URL || "default_other_url"
    }
  },
  css: ['/assets/css/main.css'],
  modules: [
    [
      '@nuxtjs/i18n',
      {
      detectBrowserLanguage: {
        useCookie: true,
        cookieKey: 'i18n_redirected',
        redirectOn: 'root',  // recommended
      },
      lazy: true,
      legacy: false,
      langDir: 'locales',
      strategy: 'prefix_except_default',
      defaultLocale: 'en',
      locales: [
        {
          code: "en",
          iso: "en-US",
          name: "English(US)",
          file: "en-US.json"
        },
        {
          code: "ru",
          iso: "ru-RU",
          name: "Русский",
          file: "ru-RU.json"
        },
        {
          code: "uk",
          iso: "uk-UA",
          name: "Український",
          file: "uk-UA.json"
        }
      ]
      }
    ],
    '@formkit/auto-animate/nuxt',
    '@nuxtjs/tailwindcss',
    'nuxt-icon',
    'nuxt-swiper',
    ['@nuxtjs/google-fonts', {
      families: {
        'Nunito+Sans':  {wght:[300, 400, 500, 600], ital: [300, 400]},
      }
    }],
    "@nuxt/image"
  ],
  devtools: { enabled: false },
  app:{
    rootId: "app",
    head: {
      charset: 'utf-8',
      viewport: 'width=device-width, initial-scale=1',
    }
  }
})