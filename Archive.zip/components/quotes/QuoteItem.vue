<template>
  <IntersectionObserver
    class="transition-all flex flex-col gap-5 relative py-5">
    <div class="text-lg font-medium" v-html="query.attributes.Quote.Quote"></div>
    <div class="font-light" v-html="query.attributes.Quote.Sign"></div>
  </IntersectionObserver>
</template>

<script>
export default {
  props: {
    query: Object,
  },
};
</script>
