<template>
    <div
      :class="!filtersBar ? 'px-4 lg:px-8' : 'px-4 lg:pr-8 lg:px-0 '"
      class="fixed lg:sticky w-full border-t lg:border-b lg:border-0 z-30 bottom-0 bg-white pt-4 pb-3 lg:top-10 left-0 flex transition-all flex-row w-full justify-between right-0 font-medium text-gray-500"
    >
      <div class="flex gap-4 items-center flex-row w-3/12 lg:w-full">
        <transition name="fade">
        <div v-show="queryAmount"
          class="lg:hidden hover:text-gray-900 flex-none cursor-pointer"
          @click="toggleFilters"
          v-text="
            !filtersBar
              ? `${$t('Filters')} [${filters.length}]`
              : `${$t('Close')}`
          "></div>
        </transition>
        <transition name="fade">
        <BackToLink v-show="queryAmount" class="hidden lg:block" :label="$t('Library')" prefix="library"></BackToLink>
      </transition>
        <FilterList
          v-if="!filtersBar"
          class="hidden lg:flex w-fit"
          :filters="filters"
          :removeFilterItem="removeFilterItem"
        ></FilterList>
      </div>
      <div
        class="w-full justify-end gap-6 flex-row items-center flex w-9/12 lg:w-full"
      >
        <div><transition name="fade"><span v-show="queryAmount">{{ queryAmount }}</span></transition> {{ $t("Quotes") }}</div>
        <div class="px-2 block lg:hidden" @click="toggleSearch()">
          <Icon
            class="transition-all cursor-pointer hover:scale-105 hover:text-gray-900 text-gray-500"
            name="la:search"
            size="1.5em"
          />
        </div>
      </div>
    </div>
  <div class="[&>div.active]:bottom-[3em] [&>div]:bottom-[-100%]">
    <div
      :class="searchShow ? 'active' : ''"
      class="transition-all duration-500 fixed lg:block py-3 px-4 w-full bg-white border-t z-20"
    >
      <input
        :value="searchRequest ? searchRequest : ''"
        :placeholder="$t('Search')"
        type="email"
        class="lg:text-lg w-full xl:w-1/2 lg:col-span-2 bg-transparent focus:ring-0 focus:outline-0"
        @input="searchQuery($event)"
      />
    </div>
  </div>
</template>

<script>
export default {
  setup() {
    const runtimeConfig = useRuntimeConfig();
    return {
      runtimeConfig,
    };
  },
  props: {
    filters: Array,
    filtersBar: Boolean,
    queryAmount: Number,
    removeFilterItem: Function,
    searchRequest: String,
    searchQuery: Function,
  },
  data() {
    return {
      searchShow: false,
    };
  },
  emits: ["statusChange", "viewChange"], // Объявление кастомного события
  methods: {
    handleResize() {
      this.searchShow = false;
    },
    toggleSearch() {
      this.searchShow = !this.searchShow;
    },
    toggleFilters() {
      this.$emit("statusChange", !this.filtersBar);
    },
  },
  mounted() {
    console.log(this.view);
    window.addEventListener("resize", this.handleResize);
  },
  destroyed() {
    window.removeEventListener("resize", this.handleResize);
  },
};
</script>
