<template>
  <IntersectionObserver class="group [&>div]:cursor-pointer transition-all flex flex-col gap-5 relative py-5">
    <NuxtLinkLocale :to="query.attributes.slug ? `/exhibitions/${query.attributes.slug}` : null" class="h-fit flex text-md md:text-base flex-col font-medium">
        <div class="text-gray-400 mb-2">
            {{ query.attributes.Type }}
        </div>
        <div :class="query.attributes.slug ? `before:content-['•'] group-hover:before:mr-4 before:mr-2` : null" class="before:transition-all before:text-sm before:text-gray-400 text-lg md:text-xl">
            {{ query.attributes.Title }}
        </div>
        <div class="text-gray-400 mt-3"></div>
        <div class="text-gray-400">
            {{ query.attributes.Location }}
        </div>
        <div class="text-gray-400 mb-2">
            {{ query.attributes.Date }}
        </div>
    </NuxtLinkLocale>
  </IntersectionObserver>
</template>


<script>
export default {
    props: {
        query: Object
    }
};
</script>

