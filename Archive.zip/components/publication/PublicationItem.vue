<template>
  <IntersectionObserver
    v-if="query.attributes"
    class="group [&>div]:cursor-pointer transition-all flex flex-col gap-5 relative py-5"
  >
    <NuxtLinkLocale
      :to="
        query.attributes.slug
          ? `/library/publications/${query.attributes.slug}`
          : null
      "
      class="h-fit flex flex-row justify-start text-md md:text-base font-medium gap-6"
    >
      <div
        v-if="query.attributes.Cover && query.attributes.Cover.data"
        class="hidden sm:flex md:hidden lg:flex justify-start items-start"
      >
        <NuxtImg
          loading="lazy"
          class="min-w-[10em] xl:min-w-[12em] max-w-[10em] xl:max-w-[12em] object-contain"
          :src="
            this.runtimeConfig.public.hubBase +
            query.attributes.Cover.data.attributes.formats.small.url
          "
        />
      </div>
      <div>
        <div class="text-gray-400 mb-2">
          {{ query.attributes.Type }}
        </div>
        <div
          :class="
            query.attributes.slug
              ? `before:content-['•'] group-hover:before:mr-4 before:mr-2`
              : null
          "
          class="before:transition-all before:text-sm before:text-gray-400 text-lg md:text-xl"
        >
          {{ query.attributes.Title }}
        </div>
        <div class="flex flex-col gap-2 mt-3">
          <div class="text-gray-400">
            {{ $t("Year") }}: <span>{{ query.attributes.Date }}</span>
          </div>
          <div class="text-gray-400" v-if="query.attributes.Author">
            {{ $t("Authors") }}: <span>{{ query.attributes.Author }}</span>
          </div>
          <div class="text-gray-400" v-if="query.attributes.Publisher">
            {{ $t("Publisher") }}: <span>{{ query.attributes.Publisher }}</span>
          </div>
          <div class="text-gray-400" v-if="query.attributes.ISBN">
            {{ $t("ISBN") }}: <span>{{ query.attributes.ISBN }}</span>
          </div>
          <div class="text-gray-400" v-if="page">
            {{ $t("Pages") }}: <span>{{ page }}</span>
          </div>
        </div>
      </div>
    </NuxtLinkLocale>
  </IntersectionObserver>
</template>

<script>
export default {
  setup() {
    const runtimeConfig = useRuntimeConfig();
    return {
      runtimeConfig,
    };
  },
  props: {
    query: Object,
    page: String,
  },
};
</script>
