<template>
  <div class="grid-cols-1 grid gap-10">
    <div v-if="query.About" class="text-justify flex flex-col gap-3">
      <div class="text-gray-500">{{$t('Description')}}</div>
      <div v-html="query.About"></div>
    </div>
    <div
      class="flex flex-col gap-6 text-lg font-medium first:[&>div>div]:text-base first:[&>div>div]:font-normal"
    ></div>
  </div>
</template>

<script>
export default {
  props: {
    query: Object,
  },
};
</script>
