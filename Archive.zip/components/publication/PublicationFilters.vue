<template>
  <div
    v-show="filters.length > 0"
    @click="getAllQuery()"
    :class="filters.length === 0 ? 'text-gray-900' : ''"
    class="text-lg cursor-pointer text-gray-900 hover:text-gray-400"
  >
    {{ $t("All Publications") }}
  </div>
  <FilterList
    class="my-5"
    :filters="filters"
    :removeFilterItem="removeFilterItem"
  ></FilterList>
  <div class="flex flex-col gap-3">
    <YearsSlider
      class="mb-5"
      v-if="queryYears && currentYearInView"
      :currentValue="currentYearInView"
      :sliderData="queryYears"
    ></YearsSlider>
    <div class="mb-5" v-if="queryType">
      <div class="text-md text-gray-400 before:transition-all">
        {{ $t("Type") }}
      </div>
      <div
        class="group text-lg flex mt-1 flex-col [&>div:not(.active)]:cursor-pointer [&>div.active]:text-gray-400 text-black hover:[&>div]:text-gray-400"
      >
        <div
          v-for="item in queryType"
          :key="item"
          :class="{ active: isFilterActive(item) }"
          @click="addFilterItem('Type', item, '$containsi', item)"
        >
          {{ item }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    currentYearInView: Number,
    filtersBar: Boolean,
    filters: Array,
    searchRequest: String,
    queryType: Array,
    queryYears: Array,
    queryCountry: Array,
    isFilterActive: Function,
    isFilterLabelActive: Function,
    removeFilterItem: Function,
    addFilterItem: Function,
    openFilter: Function,
    getAllQuery: Function,
    searchQuery: Function,
  }
};
</script>
