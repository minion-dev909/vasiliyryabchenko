<template>
    <div class="flex flex-col gap-16 h-full">
        <GeneralMediaGallery :videoControls="true" :slides="slides"></GeneralMediaGallery>
    </div>
</template>


<script>
export default {
    props: {
        slides: Object
    }
};
</script>

