<template>
      <div
        v-show="filters.length > 0"
        @click="getAllQuery()"
        :class="filters.length === 0 ? 'text-gray-900' : ''"
        class="text-lg cursor-pointer text-gray-900 hover:text-gray-400"
      >
        {{ $t("All Artworks") }}
      </div>
      <FilterList class="my-5" :filters="filters" :removeFilterItem="removeFilterItem"></FilterList>
      <div class="flex flex-col gap-3">
        <div class="mb-5" v-if="queryType">
          <div class="text-md text-gray-400 before:transition-all">
            {{ $t("Type") }}
          </div>
          <div
            class="group text-lg flex mt-1 flex-col [&>div:not(.active)]:cursor-pointer [&>div.active]:text-gray-400 text-black hover:[&>div]:text-gray-400"
          >
            <div
              v-for="item in queryType"
              :key="item"
              :class="{ active: isFilterActive('Type', item.id) }"
              @click="
                addFilterItem('Type', item.id, null, item.attributes.Title)
              "
            >
              {{ item.attributes.Title }}
            </div>
          </div>
        </div>
        <div v-if="queryArtcycles">
          <div
            class="text-md flex flex-row gap-2 items-center cursor-pointer hover:gap-3 transition-all"
            @click="openFilter('Artcycles')"
            :class="
              openedFilter !== 'Artcycles' ? 'text-black' : 'text-gray-400'
            "
          >
            <span>{{ $t("Series") }}</span>
          </div>
          <Swiper
            slides-per-view="8"
            :direction="'vertical'"
            :mousewheel="true"
            :free-mode="true"
            :watchOverflow="true"
            :pagination="{
              bulletClass: 'pagination-line',
              bulletActiveClass: 'pagination-line-active',
              clickable: true,
            }"
            :modules="[SwiperPagination, SwiperMousewheel, SwiperFreeMode]"
            v-show="openedFilter === 'Artcycles'"
            class="pagination-full-h group text-base text-lg mt-1 h-48 [&>div>div:not(.active)]:cursor-pointer [&>div>div.active]:text-gray-400 text-black hover:[&>div>div]:text-gray-400"
          >
            <SwiperSlide class="h-auto"
              v-for="item in queryArtcycles"
              :key="item"
              :class="{ active: isFilterActive('Artcycle', item.id), 'overflow-hidden': !filtersBar, }"
              @click="
                addFilterItem('Artcycle', item.id, null, item.attributes.Title)
              "
            >
            <div class="flex-none flex" >
              {{ item.attributes.Title }}
            </div>
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
</template>


<script>

export default {
    props: {
        filtersBar: Boolean,
        filters: Array,
        searchRequest: String,
        queryType: Array,
        queryArtcycles: Array,
        openedFilter: String,
        queryYears: Array,
        isFilterActive: Function,
        isFilterLabelActive: Function,
        removeFilterItem: Function,
        addFilterItem: Function,
        openFilter: Function,
        getAllQuery: Function,
        searchQuery: Function,
    },
};
</script>