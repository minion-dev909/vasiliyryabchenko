<template>
    <div class="w-full text-lg mb-5 text-gray-400 font-medium">
        <BackToLink :label="$t('All Artworks')" prefix="artwork"></BackToLink>
      </div>
      <template v-if="query">
        <div  v-if="query.Title" class="mb-10 flex-col flex">
          <div class="text-gray-500 text-lg">{{$t('Title')}}</div>
          <h1 class="text-2xl font-medium">
            <span v-text="query.Title"></span>
          </h1>
        </div>
        <div class="flex-col text-lg grid grid-cols-2 sm:grid-cols-3 lg:flex gap-5 font-medium first:[&>div>div]:text-base first:[&>div>div]:font-normal">
          <div v-if="query.Year" class="flex-col flex">
            <div class="text-gray-500">{{$t('Date')}}</div>
            <div v-text="query.Year"></div>
          </div>
          <div v-if="query.Artcycle.data" class="flex-col flex">
            <div class="text-gray-500">{{$t('Cycle')}}</div>
            <NuxtLinkLocale to="/" class="transition-all opacity-70 hover:opacity-100 before:content-['•'] before:text-sm before:text-gray-400 before:mr-2" v-text="query.Artcycle.data.attributes.Title">
            </NuxtLinkLocale>
          </div>
          <div v-if="query.Type.data" class="flex-col flex">
            <div class="text-gray-500">{{$t('Type')}}</div>
            <div v-text="query.Type.data.attributes.Title"></div>
          </div>
          <template v-if="query.Information">
          <div v-if="query.Information.Medium" class="flex-col flex">
            <div class="text-gray-500">{{$t('Medium')}}</div>
            <div v-html="query.Information.Medium"></div>
          </div>
          <div v-if="query.Information.Dimensions" class="flex-col flex">
            <div class="text-gray-500">{{$t('Dimensions')}}</div>
            <div v-html="query.Information.Dimensions"></div>
          </div>
          <div v-if="query.Information.PlaceCreated" class="flex-col flex">
            <div class="text-gray-500">{{$t('Place Created')}}</div>
            <div v-html="query.Information.PlaceCreated"></div>
          </div>
          </template>
        </div>
      </template>
</template>
<script>
export default {
    props: {
        query: Object
    }
};
</script>

