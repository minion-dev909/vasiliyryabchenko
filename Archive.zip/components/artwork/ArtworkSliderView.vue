<template>
  <Swiper
    v-if="queryAmount > 0"
    @slidesLengthChange="update($event, $el)"
    @swiper="swiperSetup($event, $el)"
    @scroll="sliderFirstMove($event)"
    @slideChange="onSlideChange($event)"
    class="pagination-fixed-bottom pagination-equal pagination-flex pagination-full-w h-[78vh] md:h-full flex flex-col justify-center items-center w-full"
    :class="slides.length < 3 ? 'swiper-auto-slides' : ''"
    :keyboard="{ enabled: true }"
    :modules="[
      SwiperKeyboard,
      SwiperFreeMode,
      SwiperNavigation,
      SwiperMousewheel,
      SwiperPagination,
      SwiperAutoplay,
    ]"
    :centered-slides="true"
    :speed="1000"
    :autoplay="{
      delay: 5000,
      disableOnInteraction: true,
      pauseOnMouseEnter: true,
    }"
    :free-mode="true"
    :mousewheel="true"
    :pagination="{
      bulletClass: 'pagination-line',
      bulletActiveClass: 'pagination-line-active',
      clickable: true,
    }"
    :slides-per-view="'auto'"
    :direction="'horizontal'"
  >
    <SwiperSlide
      v-if="Artcycle && Artcycle.Description"
      class="!flex flex-col md:py-16 md:!w-[36em] justify-center text-justify gap-4 px-4 md:px-8 lg:px-10"
    >
      <h2 v-text="Artcycle.Title" class="text-2xl"></h2>
      <Swiper
        class="pagination-full-h"
        :mousewheel="true"
        :free-mode="true"
        :modules="[SwiperFreeMode, SwiperMousewheel, SwiperPagination]"
      >
        <SwiperSlide
          class="h-[50vh]"
          v-html="Artcycle.Description"
        ></SwiperSlide>
      </Swiper>
      <div class="w-full flex flex-row mt-6">
        <div class="text-md text-gray-400 after:ml-2 after:content-['→']">
          {{$t('Scroll')}}
        </div>
      </div>
    </SwiperSlide>
    <SwiperSlide
      v-for="(slide, sl_index) in query"
      :key="sl_index"
      class="md:py-16 !w-fit"
    >
      <NuxtLinkLocale
        :to="(prefix ? `/${prefix}` : '') + `/${slide.attributes.slug}`"
        class="group flex flex-col items-center justify-center h-full gap-5"
      >
        <div>
          <template
            v-if="slide.attributes.Cover.data.attributes.mime.includes('image')"
          >
            <IntersectionObserver>
              <picture
                class="flex justify-center items-center h-full md:h-[50vh] w-full md:w-max"
              >
                <NuxtImg
                  loading="lazy"
                  :src="`${this.runtimeConfig.public.hubBase}${slide.attributes.Cover.data.attributes.formats.medium.url}`"
                  class="h-full w-auto transition-all duration-500 group-hover:scale-95 scale-[.85]"
                />
              </picture>
            </IntersectionObserver>
          </template>
          <template
            v-if="slide.attributes.Cover.data.attributes.mime.includes('video')"
          >
            <div class="flex justify-center items-center">
              <video loop autoplay muted class="w-auto">
                <source
                  :src="`${this.runtimeConfig.public.hubBase}${slide.attributes.Cover.data.attributes.url}`"
                  :type="slide.attributes.Cover.data.attributes.mime"
                />
              </video>
            </div>
          </template>
        </div>
        <div class="text-center">
          <div
            class="text-xl font-medium"
            v-text="slide.attributes.Title"
          ></div>
          <div
            class="font-medium text-gray-500"
            v-text="slide.attributes.Year"
          ></div>
        </div>
      </NuxtLinkLocale>
    </SwiperSlide>
  </Swiper>
</template>

<script>
export default {
  setup() {
    const router = useRouter();
    const refreshed = router.options.history.state.replaced;
    const refreshParameters = () => {
      if (refreshed) {
        router.replace({
          query: null,
        });
      }
    };
    const runtimeConfig = useRuntimeConfig();
    return {
      runtimeConfig,
      router,
      refreshParameters,
    };
  },
  props: {
    prefix: String,
    query: Object,
    queryAmount: Number,
    filtersBar: Boolean,
    Artcycle: Object,
  },
  computed: {
    slides() {
      // Ensure query is not undefined and has necessary data structure
      if (this.query && Array.isArray(this.query)) {
        return this.query;
      } else {
        return []; // or handle this scenario based on your requirements
      }
    },
  },
  emits: ["statusChange"],
  mounted() {
    document.body.classList.add("overflow-y-hidden");
  },
  unmounted() {
    document.body.classList.remove("overflow-y-hidden");
  },
  methods: {
    handleScroll(progress) {
      clearTimeout(this.scrollTimeout);

      this.scrollTimeout = setTimeout(() => {
        // Получение текущих параметров урла
        const currentQuery = { ...this.router.currentRoute.value.query };

        const swiperProgress = progress;
        // Добавление параметра скролла к текущим параметрам
        const queryParameters = { ...currentQuery, prgrss: swiperProgress };

        this.router.push({
          query: queryParameters,
        });
      }, 300);
    },
    sliderFirstMove(event) {
      if (window.innerWidth > 768) {
        let newValue;
        if (event.progress !== 0) {
          newValue = false;
        } else {
          newValue = true;
        }
        this.$emit("statusChange", newValue);
      }
    },
    loadProgress(swiper) {
      const { query } = this.router.currentRoute.value;
      const progress = query.prgrss || 0
      swiper.setProgress(progress, 0);
    },
    onSlideChange(event) {
      this.handleScroll(Math.round(parseFloat(event.progress) * 10000) / 10000);
    },
    swiperSetup(event) {
      this.loadProgress(event)
    },
    update(event) {
      event.setProgress(0, 1000);
    },
  },
};
</script>
