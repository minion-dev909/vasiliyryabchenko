<template>
  <div
    :class="query.Description ? 'md:grid-cols-2' : 'grid-cols-1'"
    class="grid gap-10"
  >
    <div v-if="query.Description" class="text-justify flex flex-col gap-3">
      <div class="text-gray-500">{{$t('Description')}}</div>
      <div v-html="query.Description"></div>
    </div>
    <div
      class="flex flex-col gap-6 text-lg font-medium first:[&>div>div]:text-base first:[&>div>div]:font-normal"
    >
      <div v-if="query.Collection" class="flex-col flex gap-3">
        <div class="text-gray-500">{{$t('Collection')}}</div>
        <div v-text="query.Collection"></div>
      </div>
      <div v-if="query.Location" class="flex-col flex gap-3">
        <div class="text-gray-500">{{$t('Location')}}</div>
        <div v-text="query.Location"></div>
      </div>
      <div
        v-if="
          query.ArtworkRepresentative && query.ArtworkRepresentative.length > 0
        "
        class="flex-col flex mt-6"
      >
        <div class="text-gray-500">{{$t('Representative')}}</div>
        <NuxtLink
          v-for="item in query.ArtworkRepresentative"
          :to="item.Link"
          target="_blank"
          class="group flex flex-row justify-between items-center gap-5 py-4"
        >
          <div class="flex flex-col">
            <div v-text="item.Name"></div>
            <div v-text="item.Description" class="font-normal text-base"></div>
          </div>
          <Icon
            class="transition-all cursor-pointer group-hover:scale-105 group-hover:text-gray-900 text-gray-500"
            name="tabler:external-link"
            size="1.5em"
          />
        </NuxtLink>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    query: Object,
  },
};
</script>
