<template>
            <div class="flex-col flex first:[&>div]:pt-1">
            <template v-if="query.length > 0" v-for="item, index in query" :key="index">
            <PublicationItem :page="item.Page ? item.Page : null" :query="item.publication.data"></PublicationItem>
            </template>
            </div>
</template>


<script>

export default {
    props: {
        query: Object
    },
};
</script>

