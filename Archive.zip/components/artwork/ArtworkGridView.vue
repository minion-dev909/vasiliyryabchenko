<template>
  <div v-if="query">
    <div
      v-if="Artcycle && Artcycle.Description && Artcycle.Title"
      class="pt-10 pb-10 md:py-10 text-justify flex flex-col gap-4"
      :class="!filtersBar ? 'px-4 md:px-8' : 'px-4 md:px-0 md:pr-8'"
    >
      <h2 v-text="Artcycle.Title" class="text-2xl"></h2>
      <div class="md:text-lg">
        <div v-html="limitedDescription"></div>
        <button
          class="mt-2"
          v-if="Artcycle.Description.length > 100"
          @click="DescriptionOpen = !DescriptionOpen"
        >
          {{ DescriptionOpen ? $t("Hide text") : $t("Read more") }}
        </button>
      </div>
    </div>
    <div
      class="pt-10 pb-20 md:py-10 grid grid-cols-2 2xl:grid-cols-3 md:text-lg gap-4 md:gap-8 lg:gap-16 [&>div>a>div>img]:transition-all [&>div>a>div>picture>img]:duration-500"
      :class="!filtersBar ? 'px-4 md:px-8' : 'px-4 md:px-0 md:pr-8'"
    >
      <div
        v-if="queryAmount > 0"
        v-for="(item, index) in query"
        :key="index"
        class="group flex flex-col gap-5 h-full max-h-[75vh] justify-between"
      >
        <NuxtLinkLocale
          :to="'/artwork/' + item.attributes.slug"
          class="flex flex-col gap-5 h-full justify-between"
        >
          <div class="bg-gray-50 flex h-full justify-center items-center">
            <div class="flex h-full justify-center items-center">
              <IntersectionObserver>
              <NuxtImg
                :alt="item.attributes.Cover.data.attributes.AlternativeText"
                v-if="item.attributes.Cover"
                :src="`${this.runtimeConfig.public.hubBase}${
                  item.attributes.Cover.data.attributes.formats.medium
                    ? item.attributes.Cover.data.attributes.formats.medium.url
                    : item.attributes.Cover.data.attributes.url
                }`"
                class="duration-500 transition-all group-hover:scale-[.8] max-h-[65vh] scale-75 w-full"
              />
              </IntersectionObserver>
            </div>
          </div>
          <div class="h-fit flex flex-col font-medium">
            <div class="text-lg lg:text-xl">
              {{ item.attributes.Title }}
            </div>
            <div class="text-md lg:text-base text-gray-400">
              {{ item.attributes.Year }}
            </div>
          </div>
        </NuxtLinkLocale>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  setup() {
    const runtimeConfig = useRuntimeConfig();
    return {
      runtimeConfig,
    };
  },
  data() {
    return {
      DescriptionOpen: false,
    };
  },
  props: {
    filtersBar: Boolean,
    prefix: String,
    query: Object,
    queryAmount: Number,
    Artcycle: Object,
  },
  computed: {
    slides() {
      // Ensure query is not undefined and has necessary data structure
      if (this.query && Array.isArray(this.query)) {
        return this.query;
      } else {
        return []; // or handle this scenario based on your requirements
      }
    },
    limitedDescription() {
      if (this.Artcycle && this.Artcycle.Description) {
        return this.DescriptionOpen
          ? this.Artcycle.Description
          : this.Artcycle.Description.slice(0, 150) + "...";
      }
      return "";
    },
  },
  emits: ["statusChange", "viewChange"], // Объявление кастомного события
  methods: {
    setView(view) {
      this.$emit("viewChange", view);
    },
    toggleFilters() {
      this.$emit("statusChange", !this.filtersBar);
    },
    sliderFirstMove(event) {
      let newValue;
      if (event.progress !== 0) {
        newValue = false;
      } else {
        newValue = true;
      }
      this.$emit("statusChange", newValue);
    },
  },
};
</script>
