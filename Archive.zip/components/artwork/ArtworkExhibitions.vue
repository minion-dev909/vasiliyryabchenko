<template>
            <div class="flex-col flex first:[&>div]:pt-1">
            <template v-for="exhibition in query.data" :key="exhibition">
            <ExhibitionItem :query="exhibition"></ExhibitionItem>
            </template>
            </div>
</template>


<script>
export default {
    props: {
        query: Object
    }
};
</script>

