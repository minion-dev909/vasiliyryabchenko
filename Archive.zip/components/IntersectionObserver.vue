<!-- components/IntersectionObserver.vue -->

<template>
    <div ref="intersectionElement" class="intersection-element">
      <slot />
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        intersectionObserver: null,
      };
    },
    mounted() {
      this.$nextTick(() => {
        const options = {
          root: null,
          rootMargin: '0px',
          threshold: 0.1,
        };
  
        this.intersectionObserver = new IntersectionObserver(
          this.handleIntersection,
          options
        );
  
        if (this.$refs.intersectionElement) {
          this.intersectionObserver.observe(this.$refs.intersectionElement);
        }
      });
    },
    beforeDestroy() {
      this.disconnectObserver();
    },
    methods: {
      handleIntersection(entries) {
        entries.forEach((entry) => {
          if (this.$refs.intersectionElement && entry.isIntersecting) {
            this.$refs.intersectionElement.classList.add('visible');
          } else if (this.$refs.intersectionElement) {
            this.$refs.intersectionElement.classList.remove('visible');
          }
        });
      },
      disconnectObserver() {
        if (this.intersectionObserver) {
          this.intersectionObserver.disconnect();
        }
      },
    },
  };
  </script>
  
  <style scoped>
  /* Пример CSS для анимации */
  .intersection-element {
    opacity: 0;
    transition: opacity 0.5s ease-in-out;
  }
  
  .visible {
    opacity: 1;
  }
  </style>
  