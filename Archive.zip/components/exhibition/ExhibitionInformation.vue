<template>
    <div class="w-full text-lg mb-5 text-gray-400 font-medium">
        <BackToLink :label="$t('All Exhibitions')" prefix="exhibitions"></BackToLink>
      </div>
      <template v-if="query">
        <div  v-if="query.Title" class="mb-10 flex-col flex">
          <div class="text-gray-500 text-lg">{{$t('Title')}}</div>
          <h1 class="text-2xl font-medium">
            <span v-text="query.Title"></span>
          </h1>
        </div>
        <div class="flex-col text-lg grid grid-cols-2 sm:grid-cols-3 lg:flex  gap-5 font-medium first:[&>div>div]:text-base first:[&>div>div]:font-normal">
          <div v-if="query.Date" class="flex-col flex">
            <div class="text-gray-500">{{$t('Date')}}</div>
            <div v-text="query.Date"></div>
          </div>
          <div v-if="query.Type" class="flex-col flex">
            <div class="text-gray-500">{{$t('Type')}}</div>
            <div v-text="query.Type"></div>
          </div>
          <div v-if="query.Location" class="flex-col flex">
            <div class="text-gray-500">{{$t('Location')}}</div>
            <div v-text="query.Location"></div>
          </div>
          <div v-if="query.ExternalLink" class="flex-col flex">
            <div class="text-gray-500">{{$t('Link')}}</div>
            <NuxtLink :to="query.ExternalLink.url" target="_blank"
            class="transition-all opacity-70 hover:opacity-100" 
            v-text="query.ExternalLink.title">
            </NuxtLink>
          </div>
        </div>
      </template>
</template>
<script>
export default {
    props: {
        query: Object
    }
};
</script>

