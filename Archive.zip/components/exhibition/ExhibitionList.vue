<template>
  <div v-if="query" :class="!filtersBar ? 'px-4 md:px-8' : 'px-4 md:px-0 md:pr-8'">
    <div class="flex flex-col [&>div>div]:duration-500 [&>div]:scroll-mt-[5em]">
      <ExhibitionItem
        v-if="queryAmount > 0"
        v-for="(item, index) in query"
        :key="index"
        :query="item"
        :id="generateExhibitionId(item)"
        class="last:border-b-0 border-b"
      />
      <div v-if="queryAmount === 0">
        {{ $t("Not Found") }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  setup() {
    const runtimeConfig = useRuntimeConfig();
    return {
      runtimeConfig,
    };
  },
  props: {
    query: Object,
    queryAmount: Number,
    filtersBar: Boolean
  },
  methods: {
    generateExhibitionId(exhibition) {
      const isFirstOfYear =
        this.query.find(
          (item) => item.attributes.Date === exhibition.attributes.Date
        ).id === exhibition.id;

      return isFirstOfYear ? `y${exhibition.attributes.Date}` : "";
    },
  },
};
</script>
