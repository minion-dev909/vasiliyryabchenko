<template>
  <transition name="fadedelay">
    <div
      v-show="filters"
      v-if="filters && filters.length > 0"
      class="w-full flex flex-wrap gap-2 h-fit text-md [&>div]:transition-all [&>div]:cursor-pointer hover:[&>div]:border-gray-600 [&>div]:text-gray-600 hover:[&>div]:text-gray-400"
    >
      <div
        v-for="(filter, index) in filters"
        :key="index"
        @click="removeFilterItem(index)"
        class="border px-2 py-1 overflow-hidden flex-none flex flex-row justify-center font-medium gap-2"
      >
        <span>×</span>
        <span v-text="filter.label"></span>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  props: {
    filters: Array,
    removeFilterItem: Function,
  },
};
</script>
