<template>
  <div
    v-if="query"
    class="pt-4"
    :class="!filtersBar ? 'px-4 md:px-8' : 'px-4 md:px-0 md:pr-8'"
  >
    <div class="flex flex-col transition-all [&>div>div]:duration-500 [&>div]:scroll-mt-[5em]">
      <TextsTextItem
        v-if="queryAmount > 0"
        v-for="(item, index) in query"
        :key="index"
        :query="item"
        :uniqueId="index"
        :opened="openedTextId === index"
        class="last:border-b-0 border-b"
        @open-text="handleOpenText"
      />
      <div v-if="queryAmount === 0">
        {{ $t("Not Found") }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  setup() {
    const runtimeConfig = useRuntimeConfig();
    const openedTextId = ref(null);
    return {
      runtimeConfig,
      openedTextId,
    };
  },
  props: {
    query: Object,
    queryAmount: Number,
    filtersBar: Boolean,
  },
  methods: {
    handleOpenText(textId) {
      if (this.openedTextId === textId) {
        // Если текущий открыт, то закрываем
        this.openedTextId = null;
      } else {
        // Если другой открыт, то закрываем его и открываем новый
        this.openedTextId = textId;
      }
    },
    generateId(element) {
      const isFirstOfYear =
        this.query.find(
          (item) => item.attributes.Date === element.attributes.Date
        ).id === element.id;

      return isFirstOfYear ? `y${element.attributes.Date}` : "";
    },
  },
};
</script>
