<template>
  <IntersectionObserver class="transition-all">
    <div class="wrapper" :class="opened ? 'opened' : 'opened'">
      <div class="transition-all duration-1000 border-b flex flex-col gap-5 inner relative py-5 overflow-hidden">
        <div
          class="text-lg font-medium transition-all overflow-hidden"
          v-html="query.attributes.Text"
        ></div>
        <div class="flex flex-row justify-between items-center">
          <div class="font-light" v-html="query.attributes.Sign"></div>
          <div
            class="font-light before:transition-all hover:before:opacity-100 before:opacity-0 before:content-['•'] before:mr-2 before:text-gray-400"
          >
            <button
              @click="openText"
              v-text="!opened ? $t('Read More') : $t('Hide')"
            ></button>
          </div>
        </div>
      </div>
    </div>
  </IntersectionObserver>
</template>

<script>
export default {
  props: {
    query: Object,
    uniqueId: String,
    opened: Boolean,
  },
  methods: {
    openText() {
      // Оповещаем родителя о смене состояния через событие
      this.$emit("open-text", this.uniqueId);
    },
  },
  computed: {
    displayedText() {
      const maxLength = 300;
      const text = this.query.attributes.Text || "";
      return this.opened ? text : text.slice(0, maxLength) + "...";
    },
  },
};
</script>

<style>
.wrapper{
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows 0.5s ease-out; 
}
.wrapper.opened {
  grid-template-rows: 1fr;
}
.inner {
  overflow: hidden;
}
</style>