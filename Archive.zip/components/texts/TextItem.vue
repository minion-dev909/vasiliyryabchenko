<template>
  <IntersectionObserver
    class="transition-all flex flex-col gap-7 relative py-5"
  >
    <div
      class="text-lg font-medium transition-all overflow-hidden"
      ref="section"
      :style="{ height: opened ? sectionHeight : '12em' }"
      v-html="query.attributes.Text"
    ></div>
    <div class="flex flex-row justify-between items-center">
      <div class="font-light" v-html="query.attributes.Sign"></div>
      <div
        class="font-light before:transition-all hover:before:opacity-100 before:opacity-0 before:content-['•'] before:mr-2 before:text-gray-400"
      >
        <button
          @click="toggleSection"
          v-text="!opened ? $t('Read More') : $t('Hide')"
        ></button>
      </div>
    </div>
  </IntersectionObserver>
</template>

<script>
export default {
  props: {
    query: Object,
    uniqueId: Number,
    opened: Boolean,
  },
  computed: {
    sectionHeight() {
      return this.opened ? `${this.$refs.section.scrollHeight}px` : "12em";
    },
  },
  methods: {
    handleResize(){
      this.hide()
    },
    hide(){
      this.$emit("open-text", null);
    },
    toggleSection() {
      this.$emit("open-text", this.opened ? null : this.uniqueId);
    },
  },
  deactivated(){
    window.removeEventListener('resize', this.handleResize)
    this.hide()
  },
  mounted(){
    window.addEventListener('resize', this.handleResize)
  }
};
</script>
