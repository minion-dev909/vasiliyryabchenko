<template>
<div class="grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-4 transition-all">
    <slot/>
</div>
</template>