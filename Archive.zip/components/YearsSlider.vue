<template>
  <div
    class="relative mt-6 lg:mt-8"
    v-if="sliderData && sliderValue !== null && sliderData.length > 1"
  >
    <input
      ref="slider"
      type="range"
      :min="sliderData[sliderData.length - 1]"
      :max="sliderData[0]"
      v-model="sliderValue"
      @input="handleSliderInput"
      @mouseup="handleSliderMouseUp"
    />
    <div class="flex flex-row justify-between items-center text-gray-400">
      <div>{{ sliderData[sliderData.length - 1] }}</div>
      <div>{{ sliderData[0] }}</div>
    </div>
    <Transition name="fadedelay">
      <div
        v-show="thumbPosition !== null && thumbPosition !== -50"
        class="value-indicator"
        :style="{ left: thumbPosition + 'px' }"
        v-if="sliderValue !== null && sliderData.length > 1"
      >
        <span v-text="sliderValue"></span>
      </div>
    </Transition>
  </div>
</template>

<script>
export default {
  props: {
    sliderData: Array,
    currentValue: Number,
  },
  data() {
    return {
      sliderValue: null,
      thumbPosition: null,
    };
  },
  watch: {
    currentValue(newValue) {
      this.sliderValue = newValue;
      this.updateThumbPosition();
    },
  },
  methods: {
    handleSliderInput(event) {
      const value = parseInt(event.target.value);
      const nearest = this.sliderData.reduce((prev, curr) =>
        Math.abs(curr - value) < Math.abs(prev - value) ? curr : prev
      );

      this.sliderValue = this.sliderData.includes(value) ? value : nearest;
      this.updateThumbPosition();
      this.$emit("input", this.sliderValue);
    },
    handleSliderMouseUp() {
      this.scrollToYear(this.sliderValue);
    },
    calculateThumbPosition() {
      const range = this.$refs.slider;
      if (range) {
        const min = parseInt(range.min, 10);
        const max = parseInt(range.max, 10);
        const thumbOffset =
          ((this.sliderValue - min) / (max - min)) * (range.offsetWidth - 50);
        this.thumbPosition = thumbOffset;
      }
    },
    updateThumbPosition() {
      this.calculateThumbPosition();
    },
    scrollToYear(year) {
      const element = document.getElementById(`y${year}`);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    },
    handleResize() {
      this.thumbPosition = null
      clearTimeout(this.resizeTimer);
      this.resizeTimer = setTimeout(() => {
        this.updateThumbPosition();
        console.log('resize');
      }, 1000);
    },
  },
  mounted() {
    this.sliderValue = this.currentValue;
    setTimeout(() => {
      this.updateThumbPosition();
    }, 1000);
    window.addEventListener("resize", this.handleResize);
  },
  beforeDestroy() {
    window.removeEventListener("resize", this.handleResize);
  },
};
</script>

<style>
input[type="range"] {
  border: 0;
  appearance: none;
  -webkit-appearance: none;
  margin: 10px 0;
  width: 100%;
}
input[type="range"]:focus {
  outline: none;
}
input[type="range"]::-webkit-slider-runnable-track {
  width: 100%;
  height: 3px;
  cursor: pointer;
  box-shadow: 0px 0px 0px #50555c;
  background: #ededed;
  border-radius: 0px;
  border: 0px solid #000000;
}
input[type="range"]::-webkit-slider-thumb {
  box-shadow: 0px 0px 0px #000000;
  border: 0px solid #000000;
  height: 3px;
  width: 50px;
  border-radius: 0px;
  background: #000000;
  cursor: pointer;
  -webkit-appearance: none;
  margin-top: 0px;
}
input[type="range"]:focus::-webkit-slider-runnable-track {
  background: #ededed;
}
input[type="range"]::-moz-range-track {
  width: 100%;
  height: 3px;
  cursor: pointer;
  box-shadow: 0px 0px 0px #50555c;
  background: #ededed;
  border-radius: 0px;
  border: 0px solid #000000;
}
input[type="range"]::-moz-range-thumb {
  box-shadow: 0px 0px 0px #000000;
  border: 0px solid #000000;
  height: 3px;
  width: 50px;
  border-radius: 0px;
  background: #000000;
  cursor: pointer;
}
input[type="range"]::-ms-track {
  width: 100%;
  height: 3px;
  cursor: pointer;
  background: transparent;
  border-color: transparent;
  color: transparent;
}
input[type="range"]::-ms-fill-lower {
  background: #ededed;
  border: 0px solid #000000;
  border-radius: 30px;
  box-shadow: 0px 0px 0px #50555c;
}
input[type="range"]::-ms-fill-upper {
  background: #ededed;
  border: 0px solid #000000;
  border-radius: 30px;
  box-shadow: 0px 0px 0px #50555c;
}
input[type="range"]::-ms-thumb {
  margin-top: 1px;
  box-shadow: 0px 0px 0px #000000;
  border: 0px solid #000000;
  height: 3px;
  width: 50px;
  border-radius: 0px;
  background: #000000;
  cursor: pointer;
}
input[type="range"]:focus::-ms-fill-lower {
  background: #ededed;
}
input[type="range"]:focus::-ms-fill-upper {
  background: #ededed;
}

/* Добавьте стили для позиционирования индикатора значения */
.relative {
  position: relative;
}

.value-indicator {
  position: absolute;
  top: -20px; /* Регулируйте отступ над thumb'ом */
  width: 50px;
  text-align: center;
}
</style>
