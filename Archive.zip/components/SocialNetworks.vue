<template>
    <NuxtLink v-for="item, index in items" :key="index" :to="item.Link" target="_blank"><Icon  :name="item.Icon" size="1.5em"></Icon></NuxtLink>                 
</template>

<script>
import axios from 'axios';
export default {
    setup() {
        const { locale } = useI18n()
        const runtimeConfig = useRuntimeConfig();
        return {
            runtimeConfig,
            locale
        }
    },
    data() {
        return {
            items: null
        }
    },
    methods: {
        async getQuery() {
            const request = `${this.runtimeConfig.public.apiBase}/site-information?populate=*&locale=${this.locale}`;
            try {
                const response = await axios.get(request, {
                    headers: {
                        Authorization: `Bearer ${this.runtimeConfig.public.apiToken}`
                    }
                });
                this.items = response.data.data.attributes.SocialNetworks
                console.log(this.items);
            } catch (error) {
                console.error(error);
            }
        }
    },
    async beforeMount(){
        await this.getQuery()
    }
}
</script>