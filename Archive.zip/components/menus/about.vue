<template>
    <div v-for="item, index in menuItems" class="text-xl  transition-all [&>div.active]:text-gray-900 [&>div]:text-gray-400 group-hover:[&>div]:text-gray-400 [&>div]:font-medium hover:[&>div]:!text-gray-900 [&>div]:transition-all cursor-pointer">
        <div :key="index" :class="$t(item.label) === active ? 'active' :''">
            <NuxtLinkLocale :to="item.url">{{$t(item.label)}}</NuxtLinkLocale>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        active: String
    },
    data() {
        return {
            menuItems: [{
                label: "Introduction",
                url: '/about/introduction',
            },
            {
                label: "Biography",
                url: '/about/biography',
            },
            {
                label: "Photos",
                url: '/about/photos',
            }]
        }
    }

};
</script>