<template>
  <NuxtLinkLocale class="before:content-['←'] before:transition-all hover:before:mr-4 before:mr-2" :to="getLink()">{{ label }}</NuxtLinkLocale>
</template>

<script>
export default {
  setup(props) {
    const router = useRouter();
    const getLink = function () {
      const previousPath = this.router.options.history.state.back;
      let path = '';

      // Check if previousPath starts with the specified prefix and has parameters
      if (previousPath && previousPath.startsWith(`/${props.prefix}`) && previousPath.includes('?')) {
        path = previousPath;
      } else {
        path = `/${props.prefix}`;
      }

      return path;
    };

    return {
      router,
      getLink,
    };
  },
  props: {
    prefix: String,
    label: String,
  },
};
</script>
