<template>
  <div class="text-lg sm:text-xl lg:text-base text-gray-500">
    {{ $t("Explore") }}
  </div>
  <div class="group flex flex-col h-full justify-between gap-2 lg:gap-5 ">
    <div
      class="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:flex lg:flex-col lg:gap-1 w-full"
    >
      <template v-for="(item, index) in mediums" :key="index">
        <IntersectionObserver
          class="group-hover:grayscale first:col-span-2 sm:first:col-span-1 sm:first:row-span-3 lg:first:row-span-1 [&>div]:first:h-32 sm:[&>div]:first:h-full [&>div]:h-full hover:!grayscale-0 transition-all group-hover:[&>div]:opacity-60 [&>div]:font-medium hover:[&>div]:!opacity-100 [&>div]:transition-all cursor-pointer lg:!bg-none bg-cover bg-center bg-no-repeat"
          :style="
            item.attributes.Thumbnail.data
              ? `background-image: url(${this.runtimeConfig.public.hubBase}${item.attributes.Thumbnail.data.attributes.formats.small.url});`
              : ''
          "
        >
          <div
            class="border py-5 sm:py-7 px-1 text-center lg:block flex justify-center items-center lg:border-0 lg:p-0 lg:text-start text-2xl text-white lg:text-gray-900"
          >
            <span>{{ item.attributes.Title }}</span>
          </div>
        </IntersectionObserver>
      </template>
    </div>
    <div
      class="grid grid-cols-2 gap-2 md:grid-cols-4 lg:flex lg:flex-col lg:gap-1 justify-around [&>div]:font-normal [&>div]:transition-all cursor-pointer"
    >
      <template v-for="(item, index) in infoPages" :key="index">
        <IntersectionObserver
          class="transition-all group-hover:[&>a]:opacity-60 [&>a]:font-normal lg:[&>a]:font-medium hover:[&>a]:!opacity-100 [&>a]:transition-all cursor-pointer"
        >
          <NuxtLinkLocale
            :to="item.url"
            class="block border py-3 sm:py-4 px-1 text-center h-full lg:border-0 lg:p-0 lg:text-start  lg:text-2xl text-gray-900"
            >{{ $t(item.label) }}</NuxtLinkLocale
          >
        </IntersectionObserver>
      </template>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  setup() {
    const { locale } = useI18n();
    const runtimeConfig = useRuntimeConfig();
    return {
      runtimeConfig,
      locale,
    };
  },
  data() {
    return {
      mediums: null,
      infoPages: [
        { label: "About", url: "/about/introduction" },
        { label: "Exhibitions & Shows", url: "/exhibitions" },
        { label: "Publications", url: "/library/publications" },
        { label: "Interviews", url: "/library/interviews" },
        { label: "Texts", url: "/library/texts" },
        { label: "Quotes", url: "/library/quotes" },
        { label: "News", url: "/news" },
        { label: "Shop", url: "/shop" },
      ]
    };
  },
  async beforeMount() {
    try {
      const response = await axios.get(
        `${this.runtimeConfig.public.apiBase}/mediums?populate=Thumbnail&locale=${this.locale}`,
        {
          headers: {
            Authorization: `Bearer ${this.runtimeConfig.public.apiToken}`,
          },
        }
      );
      this.mediums = response.data.data;
      console.log(response.data);
    } catch (error) {
      console.error(error);
    }
  },
};
</script>
