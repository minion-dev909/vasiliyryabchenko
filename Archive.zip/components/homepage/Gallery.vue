<template>
  <div class="w-full max-h-[60vh] sm:max-h-none h-full lg:pr-8">
    <Swiper
      class="transition-all duration-all pagination-equal h-full flex flex-col justify-center items-center w-full"
      :keyboard="{ enabled: true }"
      :modules="[
        SwiperKeyboard,
        SwiperParallax,
        SwiperAutoplay,
        SwiperPagination,
      ]"
      :parallax="true"
      :speed="1000"
      :loop="true"
     
      :centeredSlides="true"
      :pagination="{
        bulletClass: 'pagination-line',
        bulletActiveClass: 'pagination-line-active',
        clickable: true,
      }"
      :slides-per-view="1"
      :direction="'horizontal'"
    >
      <SwiperSlide
        v-for="slide in slides"
        :key="slide"
        class="relative !flex gap-10 xl:flex-row justify-center sm:justify-end xl:justify-center items-center px-4 sm:px-8 lg:px-6 py-4 sm:py-6 bg-gray-50"
      >
        <div class="w-full sm:w-auto h-full">
          <template v-if="slide.Media.data.attributes.mime.includes('image')">
            <IntersectionObserver class="w-full h-full">
              <picture
                v-show="slide.Media.data.attributes.url"
                class="flex justify-center items-center h-full"
              >
                <NuxtImg
                  loading="lazy"
                  :alt="slide.Media.data.attributes.alternativeText"
                  :src="`${runtimeConfig.public.hubBase}${slide.Media.data.attributes.url}`"
                  class="md:w-auto h-full w-full object-cover object-center sm:max-h-[55vh]"
                />
              </picture>
            </IntersectionObserver>
          </template>
        </div>
        <NuxtLinkLocale to="/"
          class="text-section group w-full px-8 sm:px-12 lg:px-16 xl:px-0 xl:w-4/12 absolute xl:static z-99 top-0 left-0 h-full justify-end xl:justify-center py-10 lg:py-16 flex flex-col gap-2 lg:gap-4"
        >
          <div
            data-swiper-parallax="100"
            data-swiper-parallax-opacity="0"
            class="font-medium lg:text-md xl:text-base flex flex-row gap-4 items-center"
          >
            <TriviaStatus v-if="slide.GreenLight"></TriviaStatus
            ><span class="text-white sm:text-black sm:mix-blend-difference">{{ slide.Label }}</span>
          </div>
          <h2
            data-swiper-parallax="200"
            data-swiper-parallax-opacity="0"
            class="font-medium text-3xl lg:text-4xl text-white sm:mix-blend-difference"
          >
            {{ slide.Header }}
          </h2>
          <div
            data-swiper-parallax="100"
            data-swiper-parallax-opacity="0"
            v-html="slide.Caption"
            class="lg:text-md font-medium xl:text-base text-white sm:text-gray-500 sm:mix-blend-difference xl:mix-blend-normal"
          ></div>
          <div
            class="group-hover:before:mr-4 before:transition-all before:content-['•'] before:text-sm before:mr-2 font-medium text-white sm:text-black sm:mix-blend-differencee"
          >
            Learn More
          </div>
        </NuxtLinkLocale>
      </SwiperSlide>
    </Swiper>
  </div>
</template>

<script setup>
import axios from "axios";
const { locale } = useI18n();
const runtimeConfig = useRuntimeConfig();
const onSlideChange = () => {
  console.log("slide change");
};

const slides = ref([]);

const fetchData = async () => {
  try {
    const response = await axios.get(
      `${runtimeConfig.public.apiBase}/homepage?populate=MainSlider&populate[1]=MainSlider.Media&locale=${locale.value}`,
      {
        headers: {
          Authorization: `Bearer ${runtimeConfig.public.apiToken}`,
        },
      }
    );
    console.log(response.data);
    slides.value = response.data.data.attributes.MainSlider;
  } catch (error) {
    console.error(error);
  }
};

onMounted(() => {
  fetchData();
});
</script>
