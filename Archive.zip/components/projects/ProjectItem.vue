<template>
    <IntersectionObserver
      v-if="query.attributes"
      class="group [&>div]:cursor-pointer transition-all flex flex-col gap-5 relative py-5"
    >
      <NuxtLinkLocale
        :to="
          query.attributes.slug
            ? `/projects/${query.attributes.slug}`
            : null
        "
        class="h-fit flex flex-col sm:flex-row justify-start text-md md:text-base font-medium gap-6"
      >
        <div
          v-if="query.attributes.Cover && query.attributes.Cover.data"
          class="flex justify-start items-start"
        >
          <NuxtImg v-if="query.attributes.Cover.data.attributes.mime.includes('image')"
            loading="lazy"
            class="w-full sm:min-w-[15em] lg:min-w-[18em] xl:min-w-[25em] sm:max-w-[15em] lg:max-w-[18em] xl:max-w-[25em] object-contain"
            :src="
              this.runtimeConfig.public.hubBase +
              query.attributes.Cover.data.attributes.formats.medium.url
            "
          />
          <video v-if="query.attributes.Cover.data.attributes.mime.includes('video')"
              loop
              autoplay
              muted
              class="w-full sm:min-w-[15em] lg:min-w-[18em] xl:min-w-[25em] sm:max-w-[15em] lg:max-w-[18em] xl:max-w-[25em] object-contain"
            >
              <source
                :src="`${this.runtimeConfig.public.hubBase}${query.attributes.Cover.data.attributes.url}`"
                :type="query.attributes.Cover.data.attributes.mime"
              />
            </video>
        </div>
        <div>
          <div class="text-gray-400 mb-2">
            {{ query.attributes.Category }}
          </div>
          <div
            :class="
              query.attributes.slug
                ? `before:content-['•'] group-hover:before:mr-4 before:mr-2`
                : null
            "
            class="before:transition-all before:text-sm before:text-gray-400 text-xl sm:text-lg md:text-xl"
          >
            {{ query.attributes.Title }}
          </div>
          <div class="flex flex-col gap-2 mt-3">
            <div class="text-gray-400">
              {{ $t("Year") }}: <span>{{ query.attributes.Date }}</span>
            </div>
            <div class="text-gray-400" v-if="query.attributes.Type">
              {{ $t("Type") }}: <span>{{ query.attributes.Type }}</span>
            </div>
            <div class="text-gray-400" v-if="query.attributes.WorkMode">
              {{ $t("Work Mode") }}: <span>{{ query.attributes.WorkMode }}</span>
            </div>
            <div class="text-gray-400" v-if="query.attributes.Status">
              {{ $t("Status") }}: <span>{{ query.attributes.Status }}</span>
            </div>
          </div>
        </div>
      </NuxtLinkLocale>
    </IntersectionObserver>
  </template>
  
  <script>
  export default {
    setup() {
      const runtimeConfig = useRuntimeConfig();
      return {
        runtimeConfig,
      };
    },
    props: {
      query: Object,
      page: String,
    },
  };
  </script>
  