<template>
  <template v-if="MediaObject.attributes.mime.includes('image')">
         <Transition name="fade">
         <picture v-show="MediaObject"
           class="flex justify-center items-center h-full py-20 px-8 lg:px-0 lg:py-0"
         >
           <img
             :alt="MediaObject.attributes.alternativeText"
             :src="`${this.runtimeConfig.public.hubBase}${MediaObject.attributes.url}`"
             class="md:w-auto"
             :class="fulscreen ? 'h-auto w-5/6 md:h-5/6' : 'max-h-[33em]'"
           />
         </picture>
       </Transition>
       </template>
       <template v-if="MediaObject.attributes.mime.includes('video')">
         <Transition name="fade">
         <div v-show="MediaObject" class="flex justify-center items-center h-full">
           <video
             @click="muteControl($event.target)"
             loop
             autoplay
             muted
             class="md:w-auto"
             :class="fulscreen ? 'h-auto w-5/6 md:h-5/6' : 'max-h-[33em]'"
           >
             <source
               :src="`${this.runtimeConfig.public.hubBase}${MediaObject.attributes.url}`"
               :type="MediaObject.attributes.mime"
             />
           </video>
         </div>
       </Transition>
       </template>
</template>

<script>
export default {
 setup() {
   const runtimeConfig = useRuntimeConfig();
   return {
     runtimeConfig,
   };
 },
 props: {
   MediaObject: Object,
   MediaCaption: String,
 },
};
</script>
