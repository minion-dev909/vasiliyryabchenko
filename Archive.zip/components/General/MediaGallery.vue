<template>
  <Swiper
    class="transition-all duration-all pagination-equal h-full flex flex-col justify-center items-center bg-gray-50 w-full"
    :class="fulscreen ? 'z-[999] !fixed top-0 left-0 w-full h-full !pt-12' : ''"
    :keyboard="{ enabled: true }"
    :modules="[
      SwiperKeyboard,
      SwiperParallax,
      SwiperAutoplay,
      SwiperPagination,
    ]"
    :parallax="true"
    :speed="1000"
    :loop="true"
    :autoplay="{
      delay: 5000,
      disableOnInteraction: true,
      pauseOnMouseEnter: true,
      loop: true,
    }"
    :centeredSlides="true"
    :pagination="{
      bulletClass: 'pagination-line',
      bulletActiveClass: 'pagination-line-active',
      clickable: true,
    }"
    :slides-per-view="1"
    :space-between="50"
    :direction="'horizontal'"
    @slideChange="onSlideChange()"
    @swiper="swiperSetup($event, $el)"
  >
    <SwiperSlide
      v-for="(slide, sl_index) in slides"
      :key="`slide_${sl_index}_${fulscreen}`"
      :class="'sl-' + sl_index"
    >
      <template v-if="slide.attributes.mime.includes('image')">
        <Transition name="fade">
          <picture
            v-show="swiper"
            class="px-6 flex justify-center items-center h-full pt-4 pb-20 xl:py-20"
          >
            <NuxtImg
              densities="x1 x2 x3"
              :key="`image_${sl_index}_${fulscreen}`"
              :alt="slide.attributes.alternativeText"
              :src="`${this.runtimeConfig.public.hubBase}${slide.attributes.url}`"
              class="md:w-auto"
              :class="
                fulscreen
                  ? 'h-auto w-full md:w-5/6 lg:w-auto lg:h-5/6'
                  : 'max-h-[33em]'
              "
            />
          </picture>
        </Transition>
      </template>
      <template v-if="slide.attributes.mime.includes('video')">
        <Transition name="fade">
          <div
            v-show="swiper"
            class="flex px-6 justify-center items-center h-full"
          >
            <video
              @click="muteControl($event.target)"
              :controls="videoControls"
              loop
              autoplay
              muted
              class="md:w-auto"
              :class="
                fulscreen
                  ? 'h-auto w-full md:w-5/6 lg:w-auto lg:h-5/6'
                  : 'max-h-[33em]'
              "
            >
              <source
                :src="`${this.runtimeConfig.public.hubBase}${slide.attributes.url}`"
                :type="slide.attributes.mime"
              />
            </video>
          </div>
        </Transition>
      </template>
    </SwiperSlide>
    <div
      class="h-12 z-10 absolute bottom-0 mb-5 px-8 w-full flex flex-row items-center justify-center gap-5"
    >
      <div @click="toggleFullscreen()" class="fullscreen-icon">
        <Icon
          class="transition-all cursor-pointer hover:scale-105 hover:text-gray-900 text-gray-500"
          name="tabler:zoom-scan"
          size="1.5em"
        />
      </div>
    </div>
  </Swiper>
</template>

<script>
export default {
  setup() {
    const runtimeConfig = useRuntimeConfig();
    return {
      runtimeConfig,
    };
  },
  props: {
    slides: Array,
    videoControls: Boolean,
  },
  data() {
    return {
      fulscreen: false,
      swiper: null,
      swiperEl: null,
      activeSlide: null,
    };
  },
  watch: {
    fulscreen(state) {
      if (state !== null) {
        if (state === true) {
          document.body.classList.add("overflow-hidden");
          window.scrollTo({
            top: 0,
          });
        } else {
          document.body.classList.remove("overflow-hidden");
        }
      }
    },
  },
  methods: {
    toggleFullscreen() {
      this.fulscreen = !this.fulscreen;
    },
    swiperSetup(event, element) {
      this.swiper = event;
      this.swiperEl = element;
      console.log(this.swiper);
    },
    getSoundMute() {
      if (this.swiper && this.swiper.slides) {
        const activeSlide = this.swiper.slides.find((slide) =>
          slide.classList.contains("swiper-slide-active")
        );
        if (activeSlide) {
          const muted = activeSlide.querySelector("video")
            ? activeSlide.querySelector("video").muted
            : false;
          return muted;
        }
      }
      return false;
    },
    setSoundMute() {
      console.log(this.swiper);
      this.swiper.slides.forEach((slide) => {
        slide.querySelector("video")
          ? this.muteControl(slide.querySelector("video"))
          : null;
      });
    },
    muteControl(video) {
      video.muted = !video.muted;
    },
    onSlideChange() {
      if (this.swiper) {
        this.swiper.slides.forEach((slide) => {
          if (slide.classList.contains("swiper-slide-active")) {
            const video = slide.querySelector("video");
            if (video && !video.muted) {
              video.muted = true;
            }
          }
        });
      }
    },
  },
};
</script>

<style>
/* Стили для полноэкранного режима */
:-webkit-full-screen {
  width: 100%;
  height: 100%;
}
:-moz-full-screen {
  width: 100%;
  height: 100%;
}
:-ms-fullscreen {
  width: 100%;
  height: 100%;
}
:fullscreen {
  width: 100%;
  height: 100%;
}
</style>
