<template>
    <template v-if="MediaObject.attributes.mime.includes('image')">
        <picture class="flex flex-col w-full justify-center items-center">
            <img :alt="`${this.runtimeConfig.public.hubBase}${MediaObject.attributes.alternativeText}`" :src="`${this.runtimeConfig.public.hubBase}${MediaObject.attributes.url}`" loop controls class="w-auto"/>
            <figcaption class="w-full font-light text-md mt-4" v-html="MediaCaption"></figcaption>
        </picture>
</template>

<template v-if="MediaObject.attributes.mime.includes('video')">
    <div class="max-h-[33em]">
        <video loop controls class="w-auto">
                <source :src="`${this.runtimeConfig.public.hubBase}${MediaObject.attributes.url}`" :type="MediaObject.attributes.mime" />
        </video>
        <div class="font-light text-md mt-4" v-html="MediaCaption"></div>
    </div>
</template>
</template>

<script>
export default {
    setup() {
        const runtimeConfig = useRuntimeConfig();
        return {
            runtimeConfig
        };
    },
    props: {
        MediaObject: Object,
        MediaCaption: String
    },
};
</script>