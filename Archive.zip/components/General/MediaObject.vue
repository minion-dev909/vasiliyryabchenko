<template>
  <template v-if="MediaObject.attributes.mime.includes('image')">
    <IntersectionObserver>
      <picture
        class="flex py-10 flex-col w-full justify-center items-center bg-gray-50"
      >
        <NuxtImg
          loading="lazy"
          :alt="`${this.runtimeConfig.public.hubBase}${MediaObject.attributes.alternativeText}`"
          :src="`${this.runtimeConfig.public.hubBase}${MediaObject.attributes.url}`"
          class="w-11/12 xl:w-10/12 2xl:w-8/12"
        />
      </picture>
    </IntersectionObserver>
    <IntersectionObserver>
      <figcaption
        class=""
        v-html="MediaCaption"
      ></figcaption>
    </IntersectionObserver>
  </template>

  <template v-if="MediaObject.attributes.mime.includes('video')">
    <div class="max-h-[33em]">
      <video loop controls class="w-auto">
        <source
          :src="`${this.runtimeConfig.public.hubBase}${MediaObject.attributes.url}`"
          :type="MediaObject.attributes.mime"
        />
      </video>
      <div class="font-light text-md mt-4" v-html="MediaCaption"></div>
    </div>
  </template>
</template>

<script>
export default {
  setup() {
    const runtimeConfig = useRuntimeConfig();
    return {
      runtimeConfig,
    };
  },
  props: {
    MediaObject: Object,
    MediaCaption: String,
  },
};
</script>
