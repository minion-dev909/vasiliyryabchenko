<template>
  <Swiper
    v-if="breakpoints"
    class="pagination-equal h-full flex flex-col justify-center items-center bg-gray-50 w-full"
    :class="slides.length < 3 ? 'swiper-auto-slides' : ''"
    :keyboard="{ enabled: true }"
    :centered-slides="true"
    :modules="[
      SwiperKeyboard,
      SwiperFreeMode,
      SwiperNavigation,
      SwiperAutoplay,
      SwiperPagination,
    ]"
    :speed="1000"
    :autoplay="{
      delay: 5000,
      disableOnInteraction: true,
      pauseOnMouseEnter: true,
    }"
    :pagination="{
      bulletClass: 'pagination-line',
      bulletActiveClass: 'pagination-line-active',
      clickable: true,
    }"
    :navigation="true"
    :slides-per-view="'auto'"
    :direction="'horizontal'"
    @swiper="SwiperInit($event)"
  >
    <SwiperSlide
      v-for="(slide, sl_index) in slides"
      :key="sl_index"
      class="flex flex-col justify-center items-center py-20 sm:!w-fit"
    >
      <NuxtLinkLocale
        :to="(prefix ? `/${prefix}` : '') + `/${slide.attributes.slug}`"
        class="group flex flex-col items-center justify-center h-full gap-5"
      >
        <div>
          <template
            v-if="slide.attributes.Cover.data.attributes.mime.includes('image')"
          >
            <picture class="flex justify-center items-center w-full h-auto md:h-96 md:w-max">
              <NuxtImg loading="lazy"
                :src="`${this.runtimeConfig.public.hubBase}${slide.attributes.Cover.data.attributes.formats.medium.url}`"
                class="h-full w-auto transition-all duration-500 group-hover:scale-95 scale-[.85]"
              />
            </picture>
          </template>
          <template
            v-if="slide.attributes.Cover.data.attributes.mime.includes('video')"
          >
            <div class="flex justify-center items-center">
              <video loop autoplay muted class="w-auto">
                <source
                  :src="`${this.runtimeConfig.public.hubBase}${slide.attributes.Cover.data.attributes.url}`"
                  :type="slide.attributes.Cover.data.attributes.mime"
                />
              </video>
            </div>
          </template>
        </div>
        <div class="text-center">
          <div
            class="text-xl font-medium"
            v-text="slide.attributes.Title"
          ></div>
          <div
            class="font-medium text-gray-500"
            v-text="slide.attributes.Year"
          ></div>
        </div>
      </NuxtLinkLocale>
    </SwiperSlide>
  </Swiper>
</template>

<script>
export default {
  setup() {
    const runtimeConfig = useRuntimeConfig();
    return {
      runtimeConfig,
    };
  },
  props: {
    promise: Array,
    prefix: String,
  },
  data() {
    return {
      slides: [],
      breakpoints: null,
    };
  },
  methods: {
    SwiperInit(event) {
      console.log(event);
    },
    setBreakpoints() {
      if (this.slides.length > 0) {
        this.breakpoints = {
          1280: { slidesPerView: this.slidesPerView("xl") },
          1024: { slidesPerView: this.slidesPerView("lg") },
          768: { slidesPerView: this.slidesPerView("md") },
          640: { slidesPerView: this.slidesPerView("sm") },
        };
        console.log(this.breakpoints);
      }
    },
    slidesPerView(screenSize) {
      const slidesAmount = this.slides.length;
      if (screenSize === "xl") {
        return Math.min(4, slidesAmount);
      } else if (screenSize === "lg") {
        return Math.min(3, slidesAmount);
      } else if (screenSize === "md") {
        return Math.min(2, slidesAmount);
      } else if (screenSize === "sm") {
        return Math.min(1, slidesAmount);
      }
      return 1;
    },
    async getSlides() {
      this.slides = this.promise;
    },
  },
  async beforeMount() {
    await this.getSlides(); // Получаем данные slides
    this.$nextTick(() => {
      this.setBreakpoints(); // Устанавливаем breakpoints после получения slides
    });
  },
};
</script>
