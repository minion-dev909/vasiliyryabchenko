<template>
    <NuxtLayout name="page-sidebar-page" class="lg:min-h-[calc(100vh-7em)] xl:min-h-[calc(100vh-6.6em)]">

<template #content v-if="query">
    <h1 class="text-3xl lg:text-4xl font-medium">
        <span>{{$t('Terms and Conditions of use')}}</span>
    </h1>
    <div v-if="query.Text" v-html="query.Text" class="[&>p>a]:underline hover:[&>p>a]:opacity-100 [&>p>a]:opacity-50">
    </div>
</template>
    </NuxtLayout>
</template>

<script>
import axios from 'axios';
export default {
    setup() {
        const { locale } = useI18n()
        const runtimeConfig = useRuntimeConfig();
        return {
            runtimeConfig,
            locale
        };
    },
    data() {
        return {
            query: null
        }
    },
    async beforeMount() {
        try {
            const response = await axios.get(`${this.runtimeConfig.public.apiBase}/terms-and-conditions?populate=*&locale=${this.locale}`, {
                headers: {
                    Authorization: `Bearer ${this.runtimeConfig.public.apiToken}`
                }
            });
            this.query = response.data.data.attributes
            console.log(this.query)
        } catch (error) {
            console.error(error);
        }
    }
};
</script>