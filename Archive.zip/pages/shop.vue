<template v-if="query">
  <NuxtLayout
    name="page-sidebar-page"
    class="lg:min-h-[calc(100vh-7em)] xl:min-h-[calc(100vh-6.6em)]"
  >
    <template #content> SHOP </template>
  </NuxtLayout>
</template>

<script>
</script>
