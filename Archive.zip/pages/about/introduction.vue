<template>
  <NuxtLayout name="page-sidebar-page-about">
    <template #content v-if="query">
      <IntersectionObserver>
        <h1 class="text-3xl lg:text-4xl font-medium">
          <span>{{ $t("Introduction") }}</span>
        </h1>
      </IntersectionObserver>
      <div v-if="query.Quote" class="text-justify font-light lg:text-start">
        <IntersectionObserver>
          <blockquote
            class="text-xl md:text-2xl xl:text-3xl mb-6 font-medium"
            v-html="query.Quote.Quote"
          ></blockquote>
        </IntersectionObserver>
        <IntersectionObserver v-html="query.Quote.Sign"></IntersectionObserver>
      </div>
      <GeneralMediaObject
        v-if="query.Media && query.Media.Media.data"
        :MediaCaption="query.Media.Caption"
        :MediaObject="query.Media.Media.data"
      ></GeneralMediaObject>
      <div
        class="text-justify lg:text-left xl:text-justify 2xl:text-left grid md:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2 gap-10"
      >
          <IntersectionObserver v-if="query.Text" class="flex flex-col xl:text-lg gap-12">
            <div class="flex-col flex gap-3">
              <div class="text-gray-500">{{ $t("Description") }}</div>
              <div v-html="query.Text"></div>
            </div>
          </IntersectionObserver>
        <IntersectionObserver class="flex flex-col gap-12 xl:text-lg">
          <div v-if="query.Education" class="flex-col flex gap-3">
            <div class="text-gray-500">{{ $t("Education") }}</div>
            <div v-html="query.Education"></div>
          </div>
          <div v-if="query.Awards" class="flex-col flex gap-3">
            <div class="text-gray-500">{{ $t("Awards") }}</div>
            <div v-html="query.Awards"></div>
          </div>
          <div v-if="query.MuseumCollections" class="flex-col flex gap-3">
            <div class="text-gray-500">{{ $t("Museum Collections") }}</div>
            <div v-html="query.MuseumCollections"></div>
          </div>
        </IntersectionObserver>
      </div>
    </template>
  </NuxtLayout>
</template>

<script setup>
const { locale } = useI18n();
const runtimeConfig = useRuntimeConfig();
const query = ref(null);

async function fetchData() {
  try {
    const url = `${runtimeConfig.public.apiBase}/introduction?populate[Quote]=*&populate[Media][populate][0]=Media&locale=${locale.value}`;
    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${runtimeConfig.public.apiToken}`,
        'Content-Type': 'application/json'
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.json();
    query.value = data.data.attributes;
    console.log(query.value);
  } catch (error) {
    console.error(error);
  }
}

onMounted(() => {
  document.body.classList.remove('overflow-hidden');
  fetchData();
});
</script>