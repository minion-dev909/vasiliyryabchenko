<template>
  <NuxtLayout name="page-sidebar-page-about">
    <template #content v-if="query">
      <h1 class="text-3xl lg:text-4xl font-medium">
        <span>{{ $t("Photos") }}</span>
      </h1>
      <div>
        <div v-for="decade in Object.keys(groupedPhotos)" :key="decade">
          <h2 class="text-xl font-semibold pb-5 text-gray-400">{{ decade }}</h2>
          <div class="grid-cols-2 md:grid-cols-3 grid gap-4 md:gap-8 pb-12">
            <div
              class="flex justify-center items-center bg-gray-50 p-10"
              v-for="photo in groupedPhotos[decade]"
              :key="photo.Photo.Alt"
            >
              <NuxtImg
                loading="lazy"
                :src="`${runtimeConfig.public.hubBase}${photo.Photo.data.attributes.url}`"
                :alt="photo.Photo.Alt"
              />
            </div>
          </div>
        </div>
      </div>
    </template>
  </NuxtLayout>
</template>

<script setup>
const query = ref(null);
const groupedPhotos = ref({});
const runtimeConfig = useRuntimeConfig();
const { locale } = useI18n();

function groupPhotosByDecade(photos) {
  return photos.reduce((result, photo) => {
    const decade = extractDecade(photo.year);
    if (!result[decade]) {
      result[decade] = [];
    }
    result[decade].push(photo);
    return result;
  }, {});
}

function extractDecade(year) {
  // Check if the year already contains 's', if not, add 's'
  return String(year).includes('s') ? String(year) : Math.floor(year / 10) * 10 + 's';
}

async function fetchData() {
  try {
    const url = `${runtimeConfig.public.apiBase}/photo?populate[Photos][populate][0]=Photo&locale=${locale.value}`;
    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${runtimeConfig.public.apiToken}`,
        'Content-Type': 'application/json'
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.json();
    query.value = data.data.attributes;
    groupedPhotos.value = groupPhotosByDecade(query.value.Photos);
    console.log(query.value);
  } catch (error) {
    console.error(error);
  }
}

onMounted(() => {
  document.body.classList.remove('overflow-hidden');
  fetchData();
});
</script>
