<template>
  <NuxtLayout name="page-sidebar-page-about">
    <template #content v-if="biography">
      <IntersectionObserver>
        <h1 class="text-3xl lg:text-4xl font-medium">
          <span>{{ $t("Biography") }}</span>
        </h1>
      </IntersectionObserver>
      <IntersectionObserver>
        <div
          v-if="biography.Text"
          class="xl:text-lg text-justify xl:columns-2 gap-6"
          v-html="biography.Text"
        ></div>
      </IntersectionObserver>
    </template>
  </NuxtLayout>
</template>

<script setup>
const biography = ref(null);
const runtimeConfig = useRuntimeConfig();
const { locale } = useI18n();

async function fetchBiography() {
  try {
    const url = `${runtimeConfig.public.apiBase}/biography?populate=*&locale=${locale.value}`;
    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${runtimeConfig.public.apiToken}`,
        'Content-Type': 'application/json'
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.json();
    biography.value = data.data.attributes;
    console.log(biography.value);
  } catch (error) {
    console.error(error);
  }
}

onMounted(() => {
  document.body.classList.remove('overflow-hidden');
  fetchBiography();
});
</script>
