<template>
  <NuxtLayout v-if="query"
    name="page-sidebar-page-grid"
    :class="(query.RelatedMedia && query.RelatedMedia.data) ? 'lg:min-h-[calc(100vh-7em)] xl:min-h-[calc(100vh-6.6em)]' : '' "
  >
    <template #content>
      <TemplatingGrid3Cols class="border-b pb-6">
        <div class="relative lg:col-span-1 px-4 md:px-8 lg:px-0 lg:ml-8">
          <div
          :class="(query.RelatedMedia && query.RelatedMedia.data) ? 'lg:min-h-[75vh]' : '' "
            class="navigation transition-all top-[7em] mb-10 lg:block overflow-y"
          >
            <div class="lg:flex flex-col lg:gap-1 w-full group">
              <ExhibitionInformation :query="query"></ExhibitionInformation>
            </div>
          </div>
        </div>
        <div v-if="query.RelatedMedia && query.RelatedMedia.data" class="lg:col-span-2 xl:col-span-3 h-full pb-6">
          <div class="min-h-max px-0 lg:pr-8 w-full gap-10 mb-5 h-full">
            <ExhibitionMedia
              v-if="query.RelatedMedia.data"
              :slides="query.RelatedMedia.data"
            ></ExhibitionMedia>
          </div>
        </div>
        <div v-if="query.RelatedMedia && query.RelatedMedia.data" class="relative lg:col-span-1 px-4 md:px-8 lg:px-0 lg:ml-8"></div>
        <div class="lg:col-span-2 xl:col-span-3 h-full">
          <div
            class="min-h-max px-4 md:px-8 lg:px-0 lg:pr-8 w-full flex flex-col gap-10"
          >
            <ExhibitionDetails :query="query"></ExhibitionDetails>
          </div>
        </div>
      </TemplatingGrid3Cols>
      <TemplatingGrid3Cols v-if="query.publications.length > 0" class="border-b pb-6"
      >
        <div class="relative lg:col-span-1 px-4 md:px-8 lg:px-0 ml-0 lg:ml-8">
          <div
            class="navigation transition-all top-[7em] mb-10 lg:block overflow-y"
          >
            <div class="lg:flex flex-col lg:gap-1 w-full group">
              <div class="font-medium text-xl">
                {{ $t("Related Publications") }}
              </div>
            </div>
          </div>
        </div>
        <div class="lg:col-span-2 xl:col-span-3">
          <div class="pr-4 min-h-max px-4 md:px-8 lg:px-0">
            <ExhibitionPublications
            :query="query.publications"
            ></ExhibitionPublications>
          </div>
        </div>
      </TemplatingGrid3Cols>
       <TemplatingGrid3Cols  v-if="this.ExhibitedWorks && this.ExhibitedWorks.length > 0">
        <div  class="relative lg:col-span-3 xl:col-span-4 px-4 md:px-8 lg:px-0 ml-0 lg:ml-8">
          <div class="navigation transition-all mb-6 lg:block overflow-y sticky">
            <div class="lg:flex flex-col lg:gap-1 w-full group">
              <div class="font-medium text-xl"> {{ $t("Exhibited Artworks") }}</div>
            </div>
          </div>
        </div>
        <div class="lg:col-span-3 xl:col-span-4">
          <div class="min-h-max h-full w-full flex flex-col gap-10">
            <GeneralRelatedMediaSlider prefix="artwork" :promise="this.ExhibitedWorks"></GeneralRelatedMediaSlider>
          </div>
        </div>
      </TemplatingGrid3Cols>
    </template>
  </NuxtLayout>
</template>

<script>
import axios from "axios";

export default {
  setup() {
    const { locale } = useI18n();
    const route = useRoute();
    const runtimeConfig = useRuntimeConfig();
    return {
      route,
      runtimeConfig,
      locale,
    };
  },
  data() {
    return {
      query: null,
      ExhibitedWorks: null,
    };
  },
  methods: {
    async queryExhibitedWorks(request) {
      try {
        const response = await axios.get(request, {
          headers: {
            Authorization: `Bearer ${this.runtimeConfig.public.apiToken}`,
          },
        });
        console.log(response.data.data);
        this.ExhibitedWorks = response.data.data;
      } catch (error) {
        console.error(error);
      }
    },
    async getExhibitedWorks() {
      const request = `${this.runtimeConfig.public.apiBase}/artworks?filters[Exhibitions][slug][$eq]=${this.route.params.slug}&populate[Cover]=*&locale=${this.locale}`;
      await this.queryExhibitedWorks(request);
    },
    async getQuery(request) {
      try {
        const response = await axios.get(request, {
          headers: {
            Authorization: `Bearer ${this.runtimeConfig.public.apiToken}`,
          },
        });
        console.log(response);
        this.query = response.data.data[0].attributes;
        this.getExhibitedWorks();
      } catch (error) {
        console.error(error);
      }
    },
    async getSingleQuery() {
      const request = `${this.runtimeConfig.public.apiBase}/exhibitions?filters[slug][$eq]=${this.route.params.slug}&populate[RelatedMedia]=*&populate[publications][populate][publication][populate][0]=Cover&locale=${this.locale}`;
      await this.getQuery(request);
    },
  },
  async beforeMount() {
    await this.getSingleQuery();
    console.log(this.route);
  },
};
</script>
