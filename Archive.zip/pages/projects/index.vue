<template>
  <NuxtLayout name="page-sidebar-page-grid" class="pt-10">
    <template #content>
      <TemplatingGrid3Cols class="grid-cols-2">
        <div class="lg:col-span-2 flex flex-row relative px-4 md:px-8">
          <div
            :class="filtersBar ? 'lg:left-[50%]' : 'left-0'"
            class="flex flex-row justify-between items-center transition-all duration-500 relative order-last font-medium"
          >
            <h1 class="text-3xl lg:text-4xl font-medium">
              <span>{{ $t("Projects") }}</span>
            </h1>
          </div>
        </div>
        <div class="xl:col-span-2">
          <div
            class="grid lg:grid-cols-2 w-full lg:justify-items-end h-full px-4 md:px-8"
          >
            <input
              :value="searchRequest ? searchRequest : ''"
              :placeholder="$t('Search')"
              type="email"
              class="hidden md:block text-lg w-full xl:w-1/2 lg:col-span-2 bg-transparent border-b-2 focus:ring-0 focus:outline-0"
              @input="searchQuery($event)"
            />
          </div>
        </div>
      </TemplatingGrid3Cols>
      <div class="flex flex-row relative">
        <div
          class="bg-white z-10 fixed md:relative transition-all duration-500"
          :class="
            filtersBar
              ? 'h-full overflow-y-scroll md:overflow-y-clip md:h-auto opacity-100 top-0 py-20 md:py-0 w-full md:w-4/12 xl:w-3/12 px-4 md:px-8'
              : 'w-full opacity-0 md:w-0 overflow-hidden'
          "
        >
          <div
            :class="!filtersBar ? 'left-[-100%]' : 'left-0'"
            class="navigation absolute top-0 transition-all mb-6 sticky lg:block overflow-y"
          >
            <transition name="fadedelaylong">
              <div
                v-show="query"
                class="lg:flex flex-col lg:gap-1 w-full h-full group justify-center"
              >
                <ProjectsFilters
                  :filtersBar="filtersBar"
                  :filters="filters"
                  :searchRequest="searchRequest"
                  :queryType="queryType"
                  :queryCategory="queryCategory"
                  :queryWorkMode="queryWorkMode"
                  :queryStatus="queryStatus"
                  :queryYears="queryYears"
                  :currentYearInView="currentYearInView"
                  :isFilterActive="isFilterActive"
                  :isFilterLabelActive="isFilterLabelActive"
                  :removeFilterItem="removeFilterItem"
                  :addFilterItem="addFilterItem"
                  :openFilter="openFilter"
                  :getAllQuery="getAllQuery"
                  :searchQuery="searchQuery"
                ></ProjectsFilters>
              </div>
            </transition>
          </div>
        </div>
        <div
          class="transition-all duration-500"
          :class="filtersBar ? 'md:w-8/12 xl:w-9/12' : 'w-full'"
        >
          <div class="relative">
            <ProjectsViewHeader
              :filters="filters"
              :removeFilterItem="removeFilterItem"
              :filtersBar="filtersBar"
              :queryAmount="queryAmount"
              :searchRequest="searchRequest"
              :searchQuery="searchQuery"
              @statusChange="UpdateSwiperStatus"
            ></ProjectsViewHeader>
            <Transition name="fade">
              <div
                v-show="PageText"
                v-if="PageText"
                class="text-justify text-base md:text-lg py-7 duration-100"
                :class="!filtersBar ? 'px-4 md:px-8' : 'px-4 md:px-0 md:pr-8'"
                v-html="PageText"
              ></div>
            </Transition>
            <transition name="fadedelay">
              <ProjectsList
                :query="query"
                :queryAmount="queryAmount"
                :filtersBar="filtersBar"
              ></ProjectsList>
            </transition>
          </div>
        </div>
      </div>
    </template>
  </NuxtLayout>
</template>

<script>
import axios from "axios";
export default {
  setup() {
    const router = useRouter();
    const refreshed = router.options.history.state.replaced;
    const refreshParameters = () => {
      if (refreshed) {
        router.replace({
          query: null,
        });
      }
    };
    const { locale } = useI18n();
    const runtimeConfig = useRuntimeConfig();

    return {
      router,
      runtimeConfig,
      locale,
      refreshed,
      refreshParameters,
    };
  },
  data() {
    return {
      request: `${this.runtimeConfig.public.apiBase}/projects?sort=Date:desc&populate=*&locale=${this.locale}`,
      filtersBar: true,
      query: null,
      queryAmount: 0,
      searchRequest: null,
      //FILTERS
      filters: [],
      //FILTERS OPTIONS
      queryType: null,
      queryCategory: null,
      queryWorkMode: null,
      queryStatus: null,
      queryYears: null,
      currentYearInView: null,
      PageText: "",
    };
  },
  watch: {
    async filtersBar(newStatus) {
      if (newStatus !== null) {
        if (window.innerWidth <= 768) {
          newStatus === true
            ? document.body.classList.add("overflow-hidden")
            : document.body.classList.remove("overflow-hidden");
        }
      }
    },
    async query(newQuery) {
      if (newQuery !== null) {
        this.queryAmount = newQuery.length;
        this.queryType = await this.getContentTypeQuery("Type");
        this.queryCategory = await this.getContentTypeQuery("Category");
        this.queryWorkMode = await this.getContentTypeQuery("WorkMode");
        this.queryStatus = await this.getContentTypeQuery("Status");
        this.queryYears = await this.getContentTypeQuery("Date");
        await this.updateRoute();
      }
    },
  },
  methods: {
    async ResetScrollParameter() {
      window.scrollTo({
        top: 0,
      });
    },
    async updateRoute() {
      // Получение текущих параметров урла
      const currentQuery = { ...this.router.currentRoute.value.query };

      // Проверка наличия фильтров и searchRequest
      const hasFilters = this.filters.length > 0;
      const hasSearchRequest =
        this.searchRequest !== null && this.searchRequest.trim() !== "";

      // Добавление текущих параметров
      const queryParameters = { ...currentQuery };

      // Удаление параметра filters, если он пуст
      if (!hasFilters && currentQuery.filters) {
        delete queryParameters.filters;
      } else if (hasFilters) {
        // Добавление новых параметров только если они присутствуют
        queryParameters.filters = JSON.stringify(this.filters);
      }

      // Удаление параметра searchRequest, если он пуст
      if (!hasSearchRequest && currentQuery.searchRequest) {
        delete queryParameters.searchRequest;
      } else if (hasSearchRequest) {
        queryParameters.searchRequest = this.searchRequest;
      }

      // Запись параметров урла
      await this.router.replace({
        query: queryParameters,
      });
    },
    CurrentYearChangeOnScroll() {
      const scrollPosition = window.scrollY + 100;

      for (let i = this.query.length - 1; i >= 0; i--) {
        const item = this.query[i];
        const element = document.getElementById(`y${item.attributes.Date}`);

        if (element && element.offsetTop <= scrollPosition) {
          this.currentYearInView = parseInt(item.attributes.Date);
          break;
        }
      }
    },
    handleScroll() {
      this.CurrentYearChangeOnScroll();
    },
    handleResize() {
      if (window.innerWidth <= 768) {
        this.filtersBar = false;
      } else {
        this.filtersBar = true;
      }
    },
    async UpdateSwiperStatus(newValue) {
      this.filtersBar = newValue;
    },
    async searchQuery(event) {
      this.searchRequest = event.target.value.trim();
      await this.getQuery();
      this.ResetScrollParameter();
    },
    async toggleClass(event, cl) {
      event.target.classList.toggle(cl);
    },
    async getContentTypeQuery(type) {
      const array = [];
      this.query.forEach((item) => {
        const value = item.attributes[type];
        if (value && value.trim() !== "" && !array.includes(value)) {
          array.push(value);
        }
      });
      if (type === "Date") {
        this.currentYearInView = parseInt(array[0]);
      }
      return array;
    },
    async getQuery() {
      try {
        let filtersQuery = "";
        this.filters.forEach((filter) => {
          filtersQuery += filter.query;
        });

        let searchQuery;
        this.searchRequest
          ? (searchQuery = `&filters[Title][$containsi]=${this.searchRequest}`)
          : (searchQuery = "");

        const response = await axios.get(
          `${this.request}${filtersQuery}${searchQuery}`,
          {
            headers: {
              Authorization: `Bearer ${this.runtimeConfig.public.apiToken}`,
            },
          }
        );
        this.query = response.data.data;
        console.log(this.query);
      } catch (error) {
        console.error(error);
      }
    },
    async getPageText() {
      try {
        const response = await axios.get(
          `${this.runtimeConfig.public.apiBase}/projects-list?&locale=${this.locale}`,
          {
            headers: {
              Authorization: `Bearer ${this.runtimeConfig.public.apiToken}`,
            },
          }
        );
        this.PageText = response.data.data.attributes.Text;
      } catch (error) {
        console.error(error);
      }
    },
    async openFilter(type) {
      this.openedFilter = type;
    },
    async getAllQuery() {
      this.filters = [];
      this.searchRequest = "";
      await this.getQuery();
    },
    async removeFilterItem(filterKey) {
      this.filters.splice(filterKey, 1);
      await this.getQuery();
      this.ResetScrollParameter();
    },
    async addFilterItem(type, value, operator, label) {
      const query = `&filters[${type}]${
        operator ? `[${operator}]` : ""
      }=${value}`;
      const filterExists = this.filters.some(
        (filter) => filter.query.trim() === query.trim()
      );

      if (!filterExists) {
        this.filters.push({
          query: query,
          label: label || type,
        });
        await this.getQuery();
        this.ResetScrollParameter();
      }
    },
    isFilterActive(type, id) {
      return this.filters.some((filter) => {
        return filter.query.includes(`filters[${type}]=${id}`);
      });
    },
    isFilterLabelActive(label) {
      return this.filters.some((filter) => {
        return filter.label.includes(label);
      });
    },
    scrollToYear(year) {
      const element = document.getElementById(`y${year}`);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    },
    restoreScrollPosition() {
      const { query } = this.router.currentRoute.value;
      if (window.innerHeight < query.scrl && this.refreshed) {
        window.scrollTo({
          top: 0,
        });
      } else {
        window.scrollTo({
          top: query.scrl || 0,
        });
      }
      console.log(window.innerHeight + "/" + query.scrl);
    },
    loadQueryParameters() {
      const { query } = this.router.currentRoute.value;
      this.filters = query.filters ? JSON.parse(query.filters) : [];
      this.searchRequest = query.searchRequest || null;
    },
  },
  mounted() {
    this.refreshParameters();
    document.body.classList.remove("overflow-hidden");
    this.loadQueryParameters();
    this.getQuery();
    this.getPageText();
    window.addEventListener("scroll", this.handleScroll);
    window.addEventListener("resize", this.handleResize);
  },
  unmounted() {
    window.removeEventListener("scroll", this.handleScroll);
    window.removeEventListener("resize", this.handleResize);
  },
};
</script>
