<template>
    <div class="bg-white w-full">
      <NuxtLayout name="section-full">
        <template #sidecontent>
            <div class="w-full h-full flex flex-col justify-start gap-6 px-4 md:px-8">
            <HomepageExploreBar></HomepageExploreBar>
        </div>
        </template>
        <template #content>
                <HomepageGallery></HomepageGallery>
        </template>
      </NuxtLayout>
    </div>
  </template>