<template>
  <NuxtLayout name="page-sidebar-page-grid">
    <template #content>
      <TemplatingGrid3Cols class="grid-cols-2">
        <div class="lg:col-span-2 flex flex-row relative px-4 md:px-8">
          <div
            :class="filtersBar ? 'lg:left-[50%]' : 'left-0'"
            class="flex flex-row justify-between items-center transition-all duration-500 relative order-last font-medium"
          >
            <h1 class="text-3xl lg:text-4xl font-medium">
              <span>{{ $t("Artwork") }}</span>
            </h1>
          </div>
        </div>
        <div class="xl:col-span-2">
          <div
            class="grid lg:grid-cols-2 w-full lg:justify-items-end h-full px-4 md:px-8"
          >
            <input
              :value="searchRequest ? searchRequest : ''"
              :placeholder="$t('Search')"
              type="email"
              class="hidden md:block text-lg w-full xl:w-1/2 lg:col-span-2 bg-transparent border-b-2 focus:ring-0 focus:outline-0"
              @input="searchQuery($event)"
            />
          </div>
        </div>
      </TemplatingGrid3Cols>
      <div class="flex flex-row relative">
        <div
          class="bg-white z-10 fixed md:relative transition-all duration-500"
          :class="
            filtersBar
              ? 'h-full md:h-auto opacity-100 top-0 py-20 md:py-0 w-full md:w-4/12 xl:w-3/12 px-4 md:pr-3 md:pl-8 lg:px-0 lg:pr-8 lg:pl-8'
              : 'w-full opacity-0 md:w-0 overflow-hidden'
          "
        >
          <div
            :class="!filtersBar ? 'left-[-100%]' : 'left-0'"
            class="navigation absolute top-0 transition-all mb-6 sticky lg:block overflow-y"
          >
            <transition name="fadedelay">
              <div
                v-show="filtersBar"
                class="lg:flex flex-col lg:gap-1 w-full h-full group justify-center"
              >
                <ArtworkFilters
                  :filtersBar="filtersBar"
                  :filters="filters"
                  :searchRequest="searchRequest"
                  :queryType="queryType"
                  :queryArtcycles="queryArtcycles"
                  :openedFilter="openedFilter"
                  :queryYears="queryYears"
                  :isFilterActive="isFilterActive"
                  :isFilterLabelActive="isFilterLabelActive"
                  :removeFilterItem="removeFilterItem"
                  :addFilterItem="addFilterItem"
                  :openFilter="openFilter"
                  :getAllQuery="getAllQuery"
                  :searchQuery="searchQuery"
                ></ArtworkFilters>
              </div>
            </transition>
          </div>
        </div>
        <div
          class="transition-all duration-500"
          :class="filtersBar ? 'md:w-8/12 xl:w-9/12' : 'w-full'"
        >
          <div class="relative">
            <ArtworkViewHeader
              :filters="filters"
              :view="view"
              :removeFilterItem="removeFilterItem"
              :filtersBar="filtersBar"
              :queryAmount="queryAmount"
              :searchRequest="searchRequest"
              :searchQuery="searchQuery"
              @viewChange="UpdateView"
              @statusChange="UpdateSwiperStatus"
            ></ArtworkViewHeader>
            <transition name="fadedelay">
              <component
                :Artcycle="Artcycle"
                :filtersBar="filtersBar"
                :is="view === 'Gallery' ? GalleryView : GridView"
                prefix="artwork"
                :query="query"
                @statusChange="UpdateSwiperStatus"
                :queryAmount="queryAmount"
              >
              </component>
            </transition>
          </div>
        </div>
      </div>
    </template>
  </NuxtLayout>
</template>

<script>
import axios from "axios";
export default {
  setup() {
    const router = useRouter();
    const refreshed = router.options.history.state.replaced;
    const refreshParameters = () => {
      if (refreshed) {
        router.replace({
          query: null,
        });
      }
    };
    const { locale } = useI18n();
    const runtimeConfig = useRuntimeConfig();
    const GalleryView = resolveComponent("ArtworkSliderView");
    const GridView = resolveComponent("ArtworkGridView");

    return {
      router,
      runtimeConfig,
      locale,
      GalleryView,
      GridView,
      refreshed,
      refreshParameters,
    };
  },
  data() {
    return {
      view: null,
      request: `${this.runtimeConfig.public.apiBase}/artworks?populate=*&sort[0]=Year:desc&sort[2]=slug:desc&locale=${this.locale}`,
      filtersBar: false,
      query: null,
      queryAmount: 0,
      searchRequest: null,
      //FILTERS
      filters: [],
      //FILTERS OPTIONS
      openedFilter: "Artcycles",
      queryType: null,
      queryArtcycles: null,
      queryCollection: null,
      queryYears: null,
      queryMedium: null,
      //ARTCYCLE DATA
      Artcycle: {},
    };
  },
  watch: {
    async filtersBar(newStatus) {
      if (newStatus !== null) {
        if (window.innerWidth <= 768) {
          newStatus === true
            ? document.body.classList.add("overflow-hidden")
            : document.body.classList.remove("overflow-hidden");
        }
        this.saveToLocalStorage();
      }
    },
    async query(newQuery) {
      if (newQuery !== null) {
        this.queryAmount = newQuery.length;
        this.queryArtcycles = await this.getContentRelationTypeQuery(
          "Artcycle"
        );
        this.queryCollection = await this.getContentTypeQuery("Collection");
        this.queryType = await this.getContentRelationTypeQuery("Type");
        this.queryYears = await this.getContentTypeQuery("Year");
        this.queryMedium = await this.getContentTypeQuery("Medium");
        this.Artcycle = await this.getArtcycle();
        this.restoreScrollPosition();
        await this.updateRoute();
      }
    },
  },
  methods: {
    saveToLocalStorage() {
      localStorage.setItem("view", this.view);
      localStorage.setItem("ArtworksFilterBarState", this.filtersBar);
    },

    restoreFromLocalStorage() {
      const savedView = localStorage.getItem("view") || 'Gallery';
      const savedFiltersBar = localStorage.getItem("ArtworksFilterBarState") || true;

      if (savedView) {
        this.view = savedView;
      }

      if (savedFiltersBar) {
        setTimeout(() => {
          this.filtersBar = JSON.parse(savedFiltersBar);
        }, 300);
      }
    },
    async ResetScrollParameter() {
      window.scrollTo({
        top: 0,
      });
    },
    async updateRoute() {
      // Получение текущих параметров урла
      const currentQuery = { ...this.router.currentRoute.value.query };

      // Проверка наличия фильтров и searchRequest
      const hasFilters = this.filters.length > 0;
      const hasSearchRequest =
        this.searchRequest !== null && this.searchRequest.trim() !== "";

      // Добавление текущих параметров
      const queryParameters = { ...currentQuery };

      // Удаление параметра filters, если он пуст
      if (!hasFilters && currentQuery.filters) {
        delete queryParameters.filters;
      } else if (hasFilters) {
        // Добавление новых параметров только если они присутствуют
        queryParameters.filters = JSON.stringify(this.filters);
      }

      // Удаление параметра searchRequest, если он пуст
      if (!hasSearchRequest && currentQuery.searchRequest) {
        delete queryParameters.searchRequest;
      } else if (hasSearchRequest) {
        queryParameters.searchRequest = this.searchRequest;
      }

      // Запись параметров урла
      await this.router.replace({
        query: queryParameters,
      });
    },

    handleScroll() {
      const SCROLL_TIMEOUT = 300;

      clearTimeout(this.scrollTimeout);

      this.scrollTimeout = setTimeout(() => {
        // Получение текущих параметров урла
        const currentQuery = { ...this.router.currentRoute.value.query };

        const scrollPosition = window.scrollY || window.pageYOffset;
        // Добавление параметра скролла к текущим параметрам
        const queryParameters = { ...currentQuery, scrl: scrollPosition };

        this.router.replace({
          query: queryParameters,
        });
      }, SCROLL_TIMEOUT);
    },
    handleResize() {
      if (window.innerWidth <= 768) {
        this.view = "Grid";
        this.filtersBar = false;
      }
    },
    async UpdateView(newValue) {
      this.view = newValue;
      await this.ResetScrollParameter()
      this.saveToLocalStorage();
    },
    async UpdateSwiperStatus(newValue) {
      this.filtersBar = newValue;
    },
    async searchQuery(event) {
      this.searchRequest = event.target.value.trim();
      await this.getQuery();
      this.ResetScrollParameter();
    },
    async toggleClass(event, cl) {
      event.target.classList.toggle(cl);
    },
    async getContentTypeQuery(type) {
      const array = [];
      this.query.forEach((item) => {
        const value = item.attributes[type];
        if (value && value.trim() !== "" && !array.includes(value)) {
          array.push(value);
        }
      });
      return array;
    },
    async getContentRelationTypeQuery(type) {
      const array = [];
      const arrayIds = [];
      this.query.forEach((item) => {
        if (
          item.attributes[type]?.data &&
          !arrayIds.includes(item.attributes[type].data.id)
        ) {
          arrayIds.push(item.attributes[type].data.id);
          array.push(item.attributes[type].data);
        }
      });
      return array;
    },
    async getQuery() {
      try {
        let filtersQuery = "";
        this.filters.forEach((filter) => {
          filtersQuery += filter.query;
        });

        let searchQuery;
        this.searchRequest
          ? (searchQuery = `&filters[Title][$containsi]=${this.searchRequest}`)
          : (searchQuery = "");

        const response = await axios.get(
          `${this.request}${filtersQuery}${searchQuery}`,
          {
            headers: {
              Authorization: `Bearer ${this.runtimeConfig.public.apiToken}`,
            },
          }
        );
        this.query = response.data.data;
        console.log(this.query);
      } catch (error) {
        console.error(error);
      }
    },
    async openFilter(type) {
      this.openedFilter = type;
    },
    async getArtcycle() {
      const artcycleFilter = this.filters.find((filter) =>
        filter.query.includes("filters[Artcycle]")
      );

      if (artcycleFilter) {
        const artcycleId = artcycleFilter.query.match(
          /filters\[Artcycle\]=(\d+)/
        )[1]; // Получение ID артцикла из фильтра
        try {
          const artcycleResponse = await axios.get(
            `${this.runtimeConfig.public.apiBase}/artcycles?filters[id][$eq]=${artcycleId}&locale=${this.locale}`,
            {
              headers: {
                Authorization: `Bearer ${this.runtimeConfig.public.apiToken}`,
              },
            }
          );
          console.log(artcycleResponse.data.data[0].attributes);
          return artcycleResponse.data.data[0].attributes; // Установка данных артцикла в this.Artcycle
        } catch (error) {
          console.error(error);
        }
      }
    },
    async getAllQuery() {
      this.filters = [];
      this.searchRequest = "";
      await this.getQuery();
    },
    async removeFilterItem(filterKey) {
      this.filters.splice(filterKey, 1);
      await this.getQuery();
      this.ResetScrollParameter();
    },
    async addFilterItem(type, value, operator, label) {
      const query = `&filters[${type}]${
        operator ? `[${operator}]` : ""
      }=${value}`;
      const filterExists = this.filters.some(
        (filter) => filter.query.trim() === query.trim()
      );

      if (!filterExists) {
        this.filters.push({
          query: query,
          label: label || type,
        });
        await this.getQuery();
        this.ResetScrollParameter();
      }
    },
    isFilterActive(type, id) {
      return this.filters.some((filter) => {
        return filter.query.includes(`filters[${type}]=${id}`);
      });
    },
    isFilterLabelActive(label) {
      return this.filters.some((filter) => {
        return filter.label.includes(label);
      });
    },
    restoreScrollPosition() {
      const { query } = this.router.currentRoute.value;
      if (window.innerHeight < query.scrl && this.refreshed) {
        window.scrollTo({
          top: 0,
        });
      } else {
        window.scrollTo({
          top: query.scrl || 0,
        });
      }
      console.log(window.innerHeight + "/" + query.scrl);
    },
    loadQueryParameters() {
      const { query } = this.router.currentRoute.value;
      this.filters = query.filters ? JSON.parse(query.filters) : [];
      this.searchRequest = query.searchRequest || null;
    },
  },
  mounted() {
    this.refreshParameters();
    document.body.classList.remove("overflow-hidden");
    this.loadQueryParameters();
    this.getQuery();
    this.restoreFromLocalStorage();
    window.addEventListener("scroll", this.handleScroll);
    window.addEventListener("resize", this.handleResize);
  },
  unmounted() {
    window.removeEventListener("scroll", this.handleScroll);
    window.removeEventListener("resize", this.handleResize);
  },
};
</script>
