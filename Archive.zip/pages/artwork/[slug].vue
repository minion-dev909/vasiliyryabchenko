<template>
  <NuxtLayout
    name="page-sidebar-page-grid"
    class="lg:pt-16"
  >
    <template v-if="query" #content>
      <TemplatingGrid3Cols class="border-b">
        <div
          class="order-last lg:order-first relative lg:col-span-1 px-4 md:px-8 lg:px-0 lg:ml-8 py-10 lg:py-0"
        >
          <div
            class="navigation transition-all top-[7em] lg:min-h-[75vh] mb-6 sticky lg:block overflow-y"
          >
            <div class="lg:flex flex-col lg:gap-1 w-full group">
              <ArtworkInformation :query="query"></ArtworkInformation>
            </div>
          </div>
        </div>
        <div class="lg:col-span-2 xl:col-span-3 h-full">
          <div class="min-h-max px-0 lg:pr-8 w-full gap-10 mb-5 h-full">
            <ArtworkMedia :slides="query.Media.data"></ArtworkMedia>
          </div>
        </div>
      </TemplatingGrid3Cols>
      <TemplatingGrid3Cols
        v-if="query.Details"
        class="py-10 lg:py-0 border-b lg:pb-6"
      >
        <div class="relative lg:col-span-1 px-4 md:px-8 lg:px-0 ml-0 lg:ml-8">
          <div
            class="navigation transition-all top-[7em] mb-6 lg:block overflow-y sticky"
          >
            <div class="lg:flex flex-col lg:gap-1 w-full group">
              <div class="font-medium text-xl">{{ $t("Details") }}</div>
            </div>
          </div>
        </div>
        <div class="lg:col-span-2 xl:col-span-3">
          <div
            class="min-h-max px-4 md:px-8 lg:px-0 lg:pr-8 w-full flex flex-col gap-10 mb-5"
          >
            <ArtworkDetails :query="query.Details"></ArtworkDetails>
          </div>
        </div>
      </TemplatingGrid3Cols>
      <TemplatingGrid3Cols
        v-if="query.Exhibitions.data.length > 0"
        class="py-6 lg:py-0 border-b lg:pb-2"
      >
        <div class="relative lg:col-span-1 px-4 md:px-8 lg:px-0 ml-0 lg:ml-8">
          <div
            class="navigation transition-all top-[7em] mb-6 lg:block overflow-y sticky"
          >
            <div class="lg:flex flex-col lg:gap-1 w-full group">
              <div class="font-medium text-xl">
                {{ $t("Participated Exhibitions") }}
              </div>
            </div>
          </div>
        </div>
        <div class="lg:col-span-2 xl:col-span-3">
          <div class="pr-4 min-h-max px-4 md:px-8 lg:px-0">
            <ArtworkExhibitions :query="query.Exhibitions"></ArtworkExhibitions>
          </div>
        </div>
      </TemplatingGrid3Cols>
      <TemplatingGrid3Cols
        v-if="query.publications.length > 0"
        class="py-6 lg:py-0 border-b lg:pb-2"
      >
        <div class="relative lg:col-span-1 px-4 md:px-8 lg:px-0 ml-0 lg:ml-8">
          <div
            class="navigation transition-all top-[7em] mb-6 lg:block overflow-y sticky"
          >
            <div class="lg:flex flex-col lg:gap-1 w-full group">
              <div class="font-medium text-xl">
                {{ $t("Mentioned Publications") }}
              </div>
            </div>
          </div>
        </div>
        <div class="lg:col-span-2 xl:col-span-3">
          <div class="pr-4 min-h-max px-4 md:px-8 lg:px-0">
            <ArtworkPublications
              :query="query.publications"
            ></ArtworkPublications>
          </div>
        </div>
      </TemplatingGrid3Cols>
      <TemplatingGrid3Cols
        v-if="this.artcycleWorks && this.artcycleWorks.length > 0"
        class="pt-6 lg:pt-0"
      >
        <div
          class="relative lg:col-span-3 xl:col-span-4 px-4 md:px-8 lg:px-0 ml-0 lg:ml-8"
        >
          <div
            class="navigation transition-all mb-6 lg:block overflow-y sticky"
          >
            <div class="lg:flex flex-col lg:gap-1 w-full group">
              <div class="font-medium text-xl">
                {{ $t('More from') }}
                <NuxtLink
                  :to='`/artwork?filters=[{"query":"%26filters[Artcycle]=${query.Artcycle.data.id}","label":"${query.Artcycle.data.attributes.Title}"}]`'
                  class="opacity-50 hover:opacity-100 transition-all"
                  v-text="query.Artcycle.data.attributes.Title"
                ></NuxtLink>
                <span v-if="locale === 'en'" class="ml-1">{{ $t('series') }}</span>
              </div>
            </div>
          </div>
        </div>
        <div class="lg:col-span-3 xl:col-span-4">
          <div class="min-h-max h-full w-full flex flex-col gap-10">
            <GeneralRelatedMediaSlider
              prefix="artwork"
              :promise="this.artcycleWorks"
            ></GeneralRelatedMediaSlider>
          </div>
        </div>
      </TemplatingGrid3Cols>
    </template>
  </NuxtLayout>
</template>

<script>
import axios from "axios";

export default {
  setup() {
    const { locale } = useI18n();
    const route = useRoute();
    const runtimeConfig = useRuntimeConfig();
    return {
      route,
      runtimeConfig,
      locale,
    };
  },
  data() {
    return {
      query: null,
      artcycleWorks: null,
    };
  },
  methods: {
    async queryArtcycleWorks(request) {
      try {
        const response = await axios.get(request, {
          headers: {
            Authorization: `Bearer ${this.runtimeConfig.public.apiToken}`,
          },
        });
        this.artcycleWorks = response.data.data;
      } catch (error) {
        console.error(error);
      }
    },
    async getArtcycleWorks() {
      const request = `${this.runtimeConfig.public.apiBase}/artworks?filters[Artcycle][id][$eq]=${this.query.Artcycle.data.id}&filters[slug][$ne]=${this.route.params.slug}&populate[Cover]=*&populate[Information]=*&populate[Type]=*&locale=${this.locale}`;
      await this.queryArtcycleWorks(request);
    },
    async getQuery(request) {
      try {
        const response = await axios.get(request, {
          headers: {
            Authorization: `Bearer ${this.runtimeConfig.public.apiToken}`,
          },
        });
        console.log(response);
        this.query = response.data.data[0].attributes;
        this.getArtcycleWorks();
      } catch (error) {
        console.error(error);
      }
    },
    async getSingleQuery() {
      const request = `${this.runtimeConfig.public.apiBase}/artworks?filters[slug][$eq]=${this.route.params.slug}&populate[Media]=*&populate[Cover]=*&populate[Information]=*&populate[Artcycle]=*&populate[Type]=*&populate[Exhibitions]=*&populate[Details][populate]=ArtworkRepresentative&populate[publications][populate][publication][populate][0]=Cover&locale=${this.locale}`;
      await this.getQuery(request);
    },
  },
  async beforeMount() {
    document.body.classList.remove("overflow-hidden");
    await this.getSingleQuery();
    console.log(this.route);
  },
};
</script>
