<template>
  <NuxtLayout v-if="query" name="page-sidebar-page">
    <template #content v-if="query">
      <IntersectionObserver>
        <h1 class="text-3xl lg:text-4xl font-medium">
          <span>{{ $t("Library") }}</span>
        </h1>
      </IntersectionObserver>
      <IntersectionObserver>
        <div
          class="font-medium text-xl text-justify"
          v-if="query.Description"
          v-html="query.Description"
        ></div>
      </IntersectionObserver>
      <div class="pt-5 flex flex-col text-lg gap-7 group text-justify">
        <NuxtLinkLocale
          class="group-hover:text-gray-400 hover:!text-gray-900 transition-all flex flex-col gap-3"
          :href="`library/${item.url}`"
          v-for="item in query.Menu"
          :key="item"
        >
          <IntersectionObserver>
            <div class="text-xl font-medium">{{ $t(item.Label) }}</div>
            <div
              class="text-base md:text-lg font-light text-gray-500"
              v-html="item.Description"
            ></div>
          </IntersectionObserver>
        </NuxtLinkLocale>
      </div>
    </template>
  </NuxtLayout>
</template>

<script>
import axios from "axios";
export default {
  setup() {
    const { locale } = useI18n();
    const runtimeConfig = useRuntimeConfig();
    return {
      runtimeConfig,
      locale,
    };
  },
  data() {
    return {
      query: null,
    };
  },
  async beforeMount() {
    document.body.classList.remove("overflow-hidden");
    try {
      const response = await axios.get(
        `${this.runtimeConfig.public.apiBase}/library?populate=*&locale=${this.locale}`,
        {
          headers: {
            Authorization: `Bearer ${this.runtimeConfig.public.apiToken}`,
          },
        }
      );
      this.query = response.data.data.attributes;
      console.log(this.query);
    } catch (error) {
      console.error(error);
    }
  },
};
</script>
