<template>
  <div class="h-full gap-5">
    <div class="grid h-full grid-cols-1 gap-10">
      <TemplatingGrid3Cols>
        <div
          class="relative order-last md:min-h-[10em] lg:order-first lg:col-span-1 lg:pr-10"
        >
          <div
            :style="`background-image: url(${image})`"
            class="bg-cover bg-center bg-no-repeat flex flex-col h-full items-center lg:items-start justify-center lg:justify-end lg:gap-1 w-full group"
          >
            <slot name="sidecontent" />
          </div>
        </div>
        <div class="lg:col-span-2 xl:col-span-3">
          <div
            class="h-full px-4 md:px-8 lg:px-0 lg:pr-8 w-full flex flex-col md:gap-10 md:mb-5"
          >
            <slot name="content" />
          </div>
        </div>
      </TemplatingGrid3Cols>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';
const runtimeConfig = useRuntimeConfig();

const image = ref('');

const fetchData = async () => {
  try {
    const response = await axios.get(
      `${runtimeConfig.public.apiBase}/footer?populate=Images`,
      {
        headers: {
          Authorization: `Bearer ${runtimeConfig.public.apiToken}`,
        },
      }
    );
    randomImage(response.data.data.attributes.Images.data);
  } catch (error) {
    console.error('Ошибка при выполнении запроса:', error);
    // Добавьте обработку ошибок по вашему усмотрению
  }
};

const getRandomInt = (max) => {
  return Math.floor(Math.random() * max);
};

const randomImage = (array) => {
  const key = getRandomInt(array.length);
  image.value = runtimeConfig.public.hubBase + array[key].attributes.url;
  console.log(image.value);
};

onMounted(() => {
  fetchData();
});
</script>
