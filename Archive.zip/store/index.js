export const state = () => ({
    savedState: null,
  });
  
  export const mutations = {
    saveState(state) {
      state.savedState = {
        filters: this.$vm.filters,
        filtersBar: this.$vm.filtersBar,
        view: this.$vm.view,
        searchRequest: this.$vm.searchRequest,
        scrollPosition: window.scrollY,
      };
    },
    restoreState(state) {
      if (state.savedState) {
        const {
          filters,
          filtersBar,
          view,
          searchRequest,
          scrollPosition,
        } = state.savedState;
  
        this.$vm.filters = filters;
        this.$vm.filtersBar = filtersBar;
        this.$vm.view = view;
        this.$vm.searchRequest = searchRequest;
  
        // Restore scroll position
        window.scrollTo({ top: scrollPosition, behavior: "auto" });
  
        // Clear saved state after restoring
        state.savedState = null;
      }
    },
  };
  